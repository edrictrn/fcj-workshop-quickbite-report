import type {
  AdminOrder,
  Category,
  DailyRevenueRow,
  Dashboard,
  Item,
  ItemPayload,
  MenuQuery,
  OperationLog,
  Order,
  OrderStatus,
  Payment,
  PaymentMethod,
  StatusCounts,
  SystemConfig,
  TopItemRow,
  User,
} from '../types'

// Default dev setup: React runs on :5173 and FastAPI runs on :8000.
// Override with VITE_API_BASE for AWS or same-origin deployment.
const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000'

const TOKEN_KEY = 'quickbite_token'

export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY) || '',
  set: (t: string) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
}

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.status = status
  }
}

function buildQuery(params?: object) {
  const qs = new URLSearchParams()
  Object.entries(params ?? {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') qs.set(key, String(value))
  })
  const text = qs.toString()
  return text ? `?${text}` : ''
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = { ...(options.headers as Record<string, string>) }
  if (options.body) headers['Content-Type'] = 'application/json'
  const token = tokenStore.get()
  if (token) headers.Authorization = `Bearer ${token}`

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers })
  const text = await res.text()
  let data: unknown = null
  try {
    data = text ? JSON.parse(text) : null
  } catch {
    data = text
  }

  if (!res.ok) {
    const detail = (data as { detail?: unknown })?.detail ?? data ?? res.statusText
    const message = Array.isArray(detail)
      ? detail.map((d: { msg?: string }) => d.msg ?? String(d)).join('; ')
      : String(detail)
    throw new ApiError(message, res.status)
  }
  return data as T
}

async function downloadCsv(path: string, filename: string) {
  const token = tokenStore.get()
  const res = await fetch(`${API_BASE}${path}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : undefined,
  })
  if (!res.ok) {
    const msg = await res.text().catch(() => res.statusText)
    throw new ApiError(msg || res.statusText, res.status)
  }
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export const api = {
  login: (email: string, password: string) =>
    request<{ access_token: string; token_type: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  register: (name: string, email: string, password: string) =>
    request<User>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    }),
  me: () => request<User>('/auth/me'),

  menu: (params?: MenuQuery) => request<Item[]>(`/menu/${buildQuery(params)}`),
  categories: () => request<Category[]>('/menu/categories'),

  adminItems: (params?: MenuQuery & { is_available?: boolean | '' }) =>
    request<Item[]>(`/menu/admin/all${buildQuery(params)}`),
  createItem: (payload: ItemPayload) =>
    request<Item>('/menu/', { method: 'POST', body: JSON.stringify(payload) }),
  updateItem: (itemId: number, payload: Partial<ItemPayload>) =>
    request<Item>(`/menu/${itemId}`, { method: 'PATCH', body: JSON.stringify(payload) }),
  deleteItem: (itemId: number) => request<null>(`/menu/${itemId}`, { method: 'DELETE' }),
  createCategory: (name: string) =>
    request<Category>('/menu/categories', { method: 'POST', body: JSON.stringify({ name }) }),

  publicSettings: () => request<SystemConfig[]>('/settings/public'),
  adminSettings: () => request<SystemConfig[]>('/settings/admin'),
  updateSetting: (key: string, value: string, description?: string | null) =>
    request<SystemConfig>(`/settings/admin/${encodeURIComponent(key)}`, {
      method: 'PATCH',
      body: JSON.stringify({ value, description }),
    }),

  dailyRevenue: (days = 14) =>
    request<DailyRevenueRow[]>(`/reports/daily-revenue?days=${days}`),
  topItems: (limit = 10) => request<TopItemRow[]>(`/reports/top-items?limit=${limit}`),
  statusCounts: () => request<StatusCounts>('/reports/status-counts'),
  exportReport: (type: 'orders' | 'revenue' | 'items') =>
    downloadCsv(`/reports/export?type=${type}`, `quickbite_${type}.csv`),

  operationLogs: (limit = 100) => request<OperationLog[]>(`/logs/admin?limit=${limit}`),

  uploadImage: async (file: File) => {
    const fd = new FormData()
    fd.append('file', file)
    const token = tokenStore.get()
    const res = await fetch(`${API_BASE}/uploads/image`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      body: fd,
    })
    const data = await res.json().catch(() => null)
    if (!res.ok) {
      throw new ApiError((data as { detail?: string })?.detail ?? res.statusText, res.status)
    }
    return data as { url: string; key: string }
  },

  createOrder: (
    items: { item_id: number; quantity: number }[],
    note: string | null,
    payment_method: PaymentMethod = 'cod',
  ) =>
    request<Order>('/orders/', {
      method: 'POST',
      body: JSON.stringify({ items, note, payment_method }),
    }),
  myOrders: () => request<Order[]>('/orders/my'),
  lookupOrder: (orderCode: string, token: string) =>
    request<Order>(
      `/orders/lookup/${encodeURIComponent(orderCode)}?token=${encodeURIComponent(token)}`,
    ),
  allOrders: () => request<AdminOrder[]>('/orders/admin/all'),
  staffOrders: () => request<AdminOrder[]>('/orders/staff/queue'),
  dashboard: () => request<Dashboard>('/orders/admin/dashboard'),
  updateStatus: (orderId: number, status: OrderStatus) =>
    request<Order>(`/orders/${orderId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  initiatePayment: (orderId: number, method: PaymentMethod) =>
    request<Payment>('/payments/initiate', {
      method: 'POST',
      body: JSON.stringify({ order_id: orderId, method }),
    }),
  completeMockPayment: (paymentId: number, success = true) =>
    request<Payment>(`/payments/${paymentId}/mock-complete`, {
      method: 'POST',
      body: JSON.stringify({ success }),
    }),
}

export const money = (value: number) =>
  new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value || 0)
