import { Box, Stack, Typography } from '@mui/material'
import { STATUS_COLOR } from '../theme'
import type { OrderStatusHistory } from '../types'

// Detailed, timestamped log of every status transition (from order_status_history).
export default function StatusHistoryLog({ history }: { history: OrderStatusHistory[] }) {
  if (!history?.length) {
    return (
      <Typography variant="body2" color="text.secondary">
        Chưa có lịch sử cập nhật.
      </Typography>
    )
  }
  return (
    <Stack spacing={1.5}>
      {history.map((h, i) => (
        <Stack key={i} direction="row" spacing={1.5} alignItems="flex-start">
          <Box
            sx={{
              mt: 0.5,
              width: 10,
              height: 10,
              borderRadius: '50%',
              flexShrink: 0,
              bgcolor: STATUS_COLOR[h.new_status] ?? '#5A5048',
            }}
          />
          <Box>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              {h.old_status ? `${h.old_status} → ${h.new_status}` : h.new_status}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {new Date(h.created_at).toLocaleString('vi-VN')}
              {h.note ? ` · ${h.note}` : ''}
            </Typography>
          </Box>
        </Stack>
      ))}
    </Stack>
  )
}
