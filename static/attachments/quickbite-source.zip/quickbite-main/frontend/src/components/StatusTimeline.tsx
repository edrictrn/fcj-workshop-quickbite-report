import { Box, Stack, Typography } from '@mui/material'
import { STATUS_COLOR } from '../theme'
import type { OrderStatus } from '../types'

// The canonical fulfilment flow. Cancelled is handled separately (not on the rail).
const FLOW: OrderStatus[] = ['pending', 'confirmed', 'preparing', 'ready', 'completed']

const LABELS: Record<OrderStatus, string> = {
  pending: 'Chờ xác nhận',
  confirmed: 'Đã xác nhận',
  preparing: 'Đang chuẩn bị',
  ready: 'Sẵn sàng',
  completed: 'Hoàn tất',
  cancelled: 'Đã huỷ',
}

export default function StatusTimeline({ status }: { status: OrderStatus }) {
  if (status === 'cancelled') {
    return (
      <Box
        sx={{
          bgcolor: `${STATUS_COLOR.cancelled}14`,
          color: STATUS_COLOR.cancelled,
          border: '1px solid',
          borderColor: STATUS_COLOR.cancelled,
          borderRadius: 1,
          px: 1.5,
          py: 0.75,
          fontSize: 13,
          fontWeight: 600,
        }}
      >
        Đơn đã huỷ
      </Box>
    )
  }

  const activeIndex = FLOW.indexOf(status)

  return (
    <Stack direction="row" alignItems="flex-start" sx={{ width: '100%' }}>
      {FLOW.map((step, i) => {
        const done = i <= activeIndex
        const isCurrent = i === activeIndex
        return (
          <Box key={step} sx={{ flex: 1, position: 'relative', textAlign: 'center' }}>
            {/* connector line to previous node */}
            {i > 0 && (
              <Box
                sx={{
                  position: 'absolute',
                  top: 7,
                  left: '-50%',
                  width: '100%',
                  height: 2,
                  bgcolor: i <= activeIndex ? STATUS_COLOR[status] : 'divider',
                }}
              />
            )}
            <Box
              sx={{
                position: 'relative',
                width: 16,
                height: 16,
                mx: 'auto',
                borderRadius: '50%',
                bgcolor: done ? STATUS_COLOR[status] : 'background.paper',
                border: '2px solid',
                borderColor: done ? STATUS_COLOR[status] : 'divider',
                boxShadow: isCurrent ? `0 0 0 4px ${STATUS_COLOR[status]}33` : 'none',
              }}
            />
            <Typography
              variant="caption"
              sx={{
                display: 'block',
                mt: 0.5,
                fontSize: 10.5,
                lineHeight: 1.2,
                color: done ? 'text.primary' : 'text.secondary',
                fontWeight: isCurrent ? 700 : 400,
              }}
            >
              {LABELS[step]}
            </Typography>
          </Box>
        )
      })}
    </Stack>
  )
}
