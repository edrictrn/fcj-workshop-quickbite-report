import { Box, Paper, Typography } from '@mui/material'
import type { ReactNode } from 'react'

export default function MetricCard({
  label,
  value,
  accent,
  icon,
}: {
  label: string
  value: string | number
  accent?: string
  icon?: ReactNode
}) {
  return (
    <Paper
      variant="outlined"
      sx={{
        p: 2.5,
        height: '100%',
        borderTop: '3px solid',
        borderTopColor: accent ?? 'primary.main',
      }}
    >
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="overline" color="text.secondary" sx={{ letterSpacing: '0.08em' }}>
          {label}
        </Typography>
        {icon}
      </Box>
      <Typography className="mono" sx={{ fontSize: 28, fontWeight: 700, mt: 0.5 }}>
        {value}
      </Typography>
    </Paper>
  )
}
