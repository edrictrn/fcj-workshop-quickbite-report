import { Box, Button, Divider, MenuItem, Select, Stack, Typography } from '@mui/material'
import { money } from '../api/client'
import { ORDER_STATUSES, type Order, type AdminOrder, type OrderStatus } from '../types'
import StatusChip from './StatusChip'
import StatusTimeline from './StatusTimeline'

interface Props {
  order: Order | AdminOrder
  // id -> name map so we can show dish names (order items only carry item_id)
  itemNames?: Record<number, string>
  // when provided, renders the admin status selector
  onStatusChange?: (status: OrderStatus) => void
  // when provided and the order is an unpaid mock e-wallet, renders a pay button
  onPay?: () => void
  paying?: boolean
  // show the fulfilment timeline (used on customer views)
  showTimeline?: boolean
}

const isAdminOrder = (o: Order | AdminOrder): o is AdminOrder =>
  (o as AdminOrder).user !== undefined

// The signature element: a kitchen order chit. Dashed "perforation" at the top,
// mono ticket number, dish lines, and a status stamp.
export default function OrderTicket({
  order,
  itemNames,
  onStatusChange,
  onPay,
  paying,
  showTimeline,
}: Props) {
  const canPay =
    order.payment?.method === 'mock_ewallet' && order.payment?.status === 'pending'
  return (
    <Box
      sx={{
        position: 'relative',
        bgcolor: 'background.paper',
        border: '1px solid',
        borderColor: 'divider',
        borderRadius: 2,
        pt: 2.5,
        px: 2,
        pb: 2,
        overflow: 'hidden',
      }}
    >
      {/* perforation strip */}
      <Box
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 6,
          background:
            'repeating-linear-gradient(90deg, transparent 0 6px, #FAF7F1 6px 12px)',
          borderBottom: '1px dashed',
          borderColor: 'divider',
        }}
      />

      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Typography className="mono" sx={{ fontWeight: 700, fontSize: 18 }}>
          {order.order_code ?? `#${String(order.id).padStart(4, '0')}`}
        </Typography>
        <StatusChip status={order.status} />
      </Stack>

      <Typography variant="caption" color="text.secondary">
        {new Date(order.created_at).toLocaleString('vi-VN')}
        {order.payment ? ` · ${order.payment.method} / ${order.payment.status}` : ''}
      </Typography>

      {isAdminOrder(order) && (
        <Typography variant="body2" sx={{ mt: 0.5 }}>
          {order.user.name}{' '}
          <Typography component="span" variant="caption" color="text.secondary">
            ({order.user.email})
          </Typography>
        </Typography>
      )}

      <Divider sx={{ my: 1.5, borderStyle: 'dashed' }} />

      <Stack spacing={0.5}>
        {order.items.map((line, idx) => (
          <Stack key={idx} direction="row" justifyContent="space-between">
            <Typography variant="body2">
              {line.item_name ?? itemNames?.[line.item_id] ?? `Món #${line.item_id}`}{' '}
              <Typography component="span" className="mono" color="text.secondary">
                ×{line.quantity}
              </Typography>
            </Typography>
            <Typography variant="body2" className="mono">
              {money(line.price * line.quantity)}
            </Typography>
          </Stack>
        ))}
      </Stack>

      {order.note && (
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
          Ghi chú: {order.note}
        </Typography>
      )}

      <Divider sx={{ my: 1.5, borderStyle: 'dashed' }} />

      <Stack spacing={0.25}>
        <Stack direction="row" justifyContent="space-between">
          <Typography variant="body2" color="text.secondary">Tạm tính món</Typography>
          <Typography variant="body2" className="mono">{money(order.subtotal)}</Typography>
        </Stack>
        <Stack direction="row" justifyContent="space-between">
          <Typography variant="body2" color="text.secondary">Phí giao hàng</Typography>
          <Typography variant="body2" className="mono">{money(order.delivery_fee)}</Typography>
        </Stack>
        {order.tax_amount > 0 && (
          <Stack direction="row" justifyContent="space-between">
            <Typography variant="body2" color="text.secondary">Thuế/phí dịch vụ</Typography>
            <Typography variant="body2" className="mono">{money(order.tax_amount)}</Typography>
          </Stack>
        )}
        <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mt: 0.5 }}>
          <Typography sx={{ fontWeight: 700 }}>Tổng cộng</Typography>
          <Typography className="mono" sx={{ fontWeight: 700 }}>
            {money(order.total)}
          </Typography>
        </Stack>
      </Stack>

      {showTimeline && (
        <Box sx={{ mt: 2 }}>
          <StatusTimeline status={order.status} />
        </Box>
      )}

      {onPay && canPay && (
        <Button
          fullWidth
          variant="contained"
          onClick={onPay}
          disabled={paying}
          sx={{ mt: 2 }}
        >
          {paying ? 'Đang xử lý…' : 'Thanh toán mô phỏng'}
        </Button>
      )}

      {onStatusChange && (
        <Select
          fullWidth
          size="small"
          value={order.status}
          onChange={(e) => onStatusChange(e.target.value as OrderStatus)}
          sx={{ mt: 1.5 }}
        >
          {ORDER_STATUSES.map((s) => (
            <MenuItem key={s} value={s}>
              {s}
            </MenuItem>
          ))}
        </Select>
      )}
    </Box>
  )
}
