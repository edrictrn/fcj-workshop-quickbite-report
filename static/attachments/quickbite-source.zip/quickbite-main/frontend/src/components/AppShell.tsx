import {
  AppBar,
  Box,
  Button,
  CssBaseline,
  Divider,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
} from '@mui/material'
import RestaurantMenuIcon from '@mui/icons-material/RestaurantMenu'
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong'
import DashboardIcon from '@mui/icons-material/Dashboard'
import MenuBookIcon from '@mui/icons-material/MenuBook'
import AssessmentIcon from '@mui/icons-material/Assessment'
import LogoutIcon from '@mui/icons-material/Logout'
import SettingsIcon from '@mui/icons-material/Settings'
import HistoryIcon from '@mui/icons-material/History'
import SearchIcon from '@mui/icons-material/Search'
import { Outlet, useLocation, useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'

const drawerWidth = 232

function Brand({ light }: { light?: boolean }) {
  return (
    <Typography
      sx={{
        fontFamily: '"Bricolage Grotesque", sans-serif',
        fontWeight: 800,
        fontSize: 22,
        letterSpacing: '-0.02em',
        color: light ? '#fff' : 'text.primary',
      }}
    >
      Quick<Box component="span" sx={{ color: 'primary.main' }}>Bite</Box>
    </Typography>
  )
}

export default function AppShell() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const isOps = user && user.role !== 'customer'
  if (isOps) {
    const adminOnly = user.role === 'admin'
    const nav = [
      ...(adminOnly ? [{ text: 'Dashboard', icon: <DashboardIcon />, path: '/admin' }] : []),
      { text: 'Order board', icon: <ReceiptLongIcon />, path: '/admin/orders' },
      ...(adminOnly
        ? [
            { text: 'Quản lý món', icon: <MenuBookIcon />, path: '/admin/menu' },
            { text: 'Báo cáo', icon: <AssessmentIcon />, path: '/admin/report' },
            { text: 'Cấu hình', icon: <SettingsIcon />, path: '/admin/settings' },
            { text: 'Audit logs', icon: <HistoryIcon />, path: '/admin/logs' },
          ]
        : []),
      { text: 'Storefront', icon: <RestaurantMenuIcon />, path: '/menu' },
    ]
    return (
      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            '& .MuiDrawer-paper': {
              width: drawerWidth,
              boxSizing: 'border-box',
              bgcolor: 'text.primary',
              color: '#fff',
              borderRight: 'none',
            },
          }}
        >
          <Toolbar sx={{ px: 2 }}>
            <Brand light />
          </Toolbar>
          <Typography variant="caption" sx={{ px: 2, color: 'rgba(255,255,255,0.5)' }}>
            {user.role === 'admin' ? 'Admin console' : user.role === 'kitchen_staff' ? 'Kitchen queue' : 'Delivery queue'}
          </Typography>
          <Divider sx={{ my: 1, borderColor: 'rgba(255,255,255,0.12)' }} />
          <List>
            {nav.map((item) => (
              <ListItem key={item.text} disablePadding>
                <ListItemButton
                  selected={location.pathname === item.path}
                  onClick={() => navigate(item.path)}
                  sx={{
                    color: 'rgba(255,255,255,0.8)',
                    '&.Mui-selected': { bgcolor: 'rgba(232,85,42,0.22)', color: '#fff' },
                    '&.Mui-selected:hover': { bgcolor: 'rgba(232,85,42,0.3)' },
                  }}
                >
                  <ListItemIcon sx={{ color: 'inherit', minWidth: 38 }}>{item.icon}</ListItemIcon>
                  <ListItemText primary={item.text} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
          <Box sx={{ mt: 'auto', p: 2 }}>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)' }}>
              {user.name}
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.45)' }}>
              {user.role}
            </Typography>
            <Button
              size="small"
              startIcon={<LogoutIcon />}
              onClick={logout}
              sx={{ mt: 1, color: 'rgba(255,255,255,0.8)', display: 'flex' }}
            >
              Đăng xuất
            </Button>
          </Box>
        </Drawer>
        <Box component="main" sx={{ flexGrow: 1, p: { xs: 2, md: 4 }, minHeight: '100vh' }}>
          <Outlet />
        </Box>
      </Box>
    )
  }

  return (
    <Box sx={{ minHeight: '100vh' }}>
      <CssBaseline />
      <AppBar
        position="sticky"
        elevation={0}
        sx={{ bgcolor: 'background.paper', color: 'text.primary', borderBottom: '1px solid', borderColor: 'divider' }}
      >
        <Toolbar sx={{ gap: 2 }}>
          <Box component={Link} to="/menu" sx={{ textDecoration: 'none' }}>
            <Brand />
          </Box>
          <Box sx={{ flexGrow: 1 }} />
          <Button component={Link} to="/menu" startIcon={<RestaurantMenuIcon />}>
            Menu
          </Button>
          <Button component={Link} to="/lookup" startIcon={<SearchIcon />}>
            Tra cứu
          </Button>
          <Button component={Link} to="/orders" startIcon={<ReceiptLongIcon />}>
            Đơn của tôi
          </Button>
          {user ? (
            <Button onClick={logout} startIcon={<LogoutIcon />} color="inherit">
              {user.name}
            </Button>
          ) : (
            <Button component={Link} to="/login" variant="contained">
              Đăng nhập
            </Button>
          )}
        </Toolbar>
      </AppBar>
      <Box component="main" sx={{ p: { xs: 2, md: 4 }, maxWidth: 1200, mx: 'auto' }}>
        <Outlet />
      </Box>
    </Box>
  )
}
