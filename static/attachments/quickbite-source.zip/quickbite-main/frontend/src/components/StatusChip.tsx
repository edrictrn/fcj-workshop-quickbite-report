import { Box } from '@mui/material'
import { STATUS_COLOR } from '../theme'
import type { OrderStatus } from '../types'

// A "stamp" rather than a default chip — flat color block, mono label,
// echoing how a kitchen marks the state of a ticket.
export default function StatusChip({ status }: { status: OrderStatus }) {
  const color = STATUS_COLOR[status] ?? '#5A5048'
  return (
    <Box
      component="span"
      className="mono"
      sx={{
        display: 'inline-block',
        px: 1,
        py: 0.25,
        borderRadius: 1,
        fontSize: 12,
        fontWeight: 700,
        letterSpacing: '0.04em',
        textTransform: 'uppercase',
        color: '#fff',
        bgcolor: color,
      }}
    >
      {status}
    </Box>
  )
}
