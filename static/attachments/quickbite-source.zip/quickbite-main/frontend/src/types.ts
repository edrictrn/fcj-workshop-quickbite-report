// Mirrors the FastAPI Pydantic schemas in the QuickBite backend.

export type UserRole = 'customer' | 'admin' | 'kitchen_staff' | 'delivery_staff'

export interface User {
  id: number
  name: string
  email: string
  role: UserRole
}

export interface Category {
  id: number
  name: string
}

export interface Item {
  id: number
  name: string
  description: string | null
  price: number
  image_url: string | null
  is_available: boolean
  category: Category | null
}

export interface Payment {
  id: number
  order_id: number
  method: PaymentMethod
  status: PaymentStatus
  amount: number
  provider_transaction_id: string | null
  created_at: string
  updated_at: string | null
  paid_at: string | null
}

export type PaymentMethod = 'cod' | 'mock_ewallet'
export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'cancelled' | 'cod'

export interface OrderItem {
  item_id: number
  item_name: string | null
  quantity: number
  price: number
}

export interface OrderStatusHistory {
  old_status: string | null
  new_status: string
  changed_by: number | null
  note: string | null
  created_at: string
}

export interface Order {
  id: number
  order_code: string | null
  lookup_token: string | null
  status: OrderStatus
  subtotal: number
  delivery_fee: number
  tax_amount: number
  total: number
  note: string | null
  created_at: string
  items: OrderItem[]
  payment: Payment | null
  status_history: OrderStatusHistory[]
}

export interface AdminOrder extends Order {
  user: User
}

export interface Dashboard {
  total_orders: number
  total_revenue: number
  today_revenue: number
  pending_orders: number
  status_counts: Record<string, number>
  payment_counts?: Record<string, number>
  top_items: { name: string; sold: number; revenue: number }[]
}

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'preparing'
  | 'ready'
  | 'completed'
  | 'cancelled'

export const ORDER_STATUSES: OrderStatus[] = [
  'pending',
  'confirmed',
  'preparing',
  'ready',
  'completed',
  'cancelled',
]

export interface CartLine {
  item: Item
  quantity: number
}

export interface ItemPayload {
  name: string
  description: string | null
  price: number
  category_id: number
  is_available: boolean
  image_url: string | null
}

export interface MenuQuery {
  search?: string
  category_id?: number | ''
  min_price?: number | ''
  max_price?: number | ''
  sort_by?: 'id' | 'name' | 'price'
  sort_order?: 'asc' | 'desc'
}

export interface DailyRevenueRow {
  day: string
  order_count: number
  revenue: number
}

export interface TopItemRow {
  name: string
  sold: number
  revenue: number
}

export type StatusCounts = Record<string, number>

export interface SystemConfig {
  key: string
  value: string
  description: string | null
  updated_at: string | null
}

export interface OperationLog {
  id: number
  user_id: number | null
  actor_email: string | null
  actor_role: string | null
  action: string
  target_type: string
  target_id: string | null
  detail: string | null
  created_at: string
}
