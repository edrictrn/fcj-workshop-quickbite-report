import { createTheme } from '@mui/material/styles'

// Design tokens — "kitchen canteen", grounded in the restaurant/order-ticket world.
// Appetite-forward warm palette, intentionally not the default dark+green or cream+serif look.
export const tokens = {
  canvas: '#FAF7F1', // warm paper, slightly cooler than the cream cliché
  paper: '#FFFFFF',
  ink: '#1A1714', // warm near-black, used for text and the admin rail
  tomato: '#E8552A', // primary — appetite
  kitchenGreen: '#2E7D52', // secondary — fresh
  amber: '#F2A900', // pending / prep highlight
  muted: '#8A8178',
  line: '#E7E0D6',
}

// One source of truth for order-status colors. Used by chips, tickets, and the board.
export const STATUS_COLOR: Record<string, string> = {
  pending: tokens.amber,
  confirmed: '#3B82F6',
  preparing: tokens.tomato,
  ready: tokens.kitchenGreen,
  completed: '#5A5048',
  cancelled: '#C0392B',
}

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: tokens.tomato, contrastText: '#FFFFFF' },
    secondary: { main: tokens.kitchenGreen },
    background: { default: tokens.canvas, paper: tokens.paper },
    text: { primary: tokens.ink, secondary: tokens.muted },
    divider: tokens.line,
  },
  shape: { borderRadius: 12 },
  typography: {
    fontFamily: '"Inter", "Helvetica", "Arial", sans-serif',
    h1: { fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 800, letterSpacing: '-0.02em' },
    h2: { fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 800, letterSpacing: '-0.02em' },
    h3: { fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 700, letterSpacing: '-0.01em' },
    h4: { fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 700 },
    h5: { fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 700 },
    h6: { fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 700 },
    button: { textTransform: 'none', fontWeight: 600 },
  },
  components: {
    MuiButton: {
      styleOverrides: { root: { borderRadius: 10 } },
      defaultProps: { disableElevation: true },
    },
    MuiPaper: {
      styleOverrides: { root: { backgroundImage: 'none' } },
    },
  },
})

export default theme
