import { useEffect, useState } from 'react'
import { Alert, Box, Paper, Typography } from '@mui/material'
import PaidIcon from '@mui/icons-material/Paid'
import TodayIcon from '@mui/icons-material/Today'
import ReceiptIcon from '@mui/icons-material/Receipt'
import PendingActionsIcon from '@mui/icons-material/PendingActions'
import { BarChart } from '@mui/x-charts/BarChart'
import { PieChart } from '@mui/x-charts/PieChart'
import { api, money } from '../../api/client'
import { STATUS_COLOR } from '../../theme'
import type { Dashboard } from '../../types'
import MetricCard from '../../components/MetricCard'

export default function DashboardPage() {
  const [data, setData] = useState<Dashboard | null>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    api
      .dashboard()
      .then(setData)
      .catch((e) => setError(e instanceof Error ? e.message : 'Không tải được dashboard'))
  }, [])

  if (error) return <Alert severity="error">{error}</Alert>
  if (!data) return <Typography color="text.secondary">Đang tải…</Typography>

  const statusEntries = Object.entries(data.status_counts)

  return (
    <Box>
      <Typography variant="h3" sx={{ mb: 3 }}>
        Dashboard
      </Typography>

      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(4, 1fr)' },
          gap: 2,
          mb: 3,
        }}
      >
        <MetricCard label="Tổng đơn" value={data.total_orders} icon={<ReceiptIcon color="disabled" />} />
        <MetricCard
          label="Tổng doanh thu"
          value={money(data.total_revenue)}
          accent="#2E7D52"
          icon={<PaidIcon color="disabled" />}
        />
        <MetricCard
          label="Doanh thu hôm nay"
          value={money(data.today_revenue)}
          accent="#3B82F6"
          icon={<TodayIcon color="disabled" />}
        />
        <MetricCard
          label="Đơn pending"
          value={data.pending_orders}
          accent="#F2A900"
          icon={<PendingActionsIcon color="disabled" />}
        />
      </Box>

      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
          gap: 2,
        }}
      >
        <Paper variant="outlined" sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Đơn theo trạng thái
          </Typography>
          {statusEntries.length ? (
            <PieChart
              height={260}
              series={[
                {
                  data: statusEntries.map(([status, count], i) => ({
                    id: i,
                    value: count,
                    label: status,
                    color: STATUS_COLOR[status] ?? '#5A5048',
                  })),
                  innerRadius: 50,
                  paddingAngle: 2,
                },
              ]}
            />
          ) : (
            <Typography color="text.secondary">Chưa có dữ liệu.</Typography>
          )}
        </Paper>

        <Paper variant="outlined" sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Top món bán chạy
          </Typography>
          {data.top_items.length ? (
            <BarChart
              height={260}
              layout="horizontal"
              yAxis={[{ scaleType: 'band', data: data.top_items.map((t) => t.name) }]}
              series={[
                {
                  data: data.top_items.map((t) => t.sold),
                  label: 'Số lượng bán',
                  color: '#E8552A',
                },
              ]}
              margin={{ left: 120 }}
            />
          ) : (
            <Typography color="text.secondary">Chưa có dữ liệu.</Typography>
          )}
        </Paper>
      </Box>
    </Box>
  )
}
