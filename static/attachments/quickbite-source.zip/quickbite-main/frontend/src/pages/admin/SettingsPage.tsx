import { useEffect, useState } from 'react'
import { Alert, Box, Button, Paper, Snackbar, Stack, TextField, Typography } from '@mui/material'
import { api } from '../../api/client'
import type { SystemConfig } from '../../types'

export default function SettingsPage() {
  const [rows, setRows] = useState<SystemConfig[]>([])
  const [values, setValues] = useState<Record<string, string>>({})
  const [error, setError] = useState('')
  const [toast, setToast] = useState('')

  const load = () => {
    api.adminSettings()
      .then((data) => {
        setRows(data)
        setValues(Object.fromEntries(data.map((r) => [r.key, r.value])))
      })
      .catch((e) => setError(e instanceof Error ? e.message : 'Không tải được cấu hình'))
  }

  useEffect(() => {
    load()
  }, [])

  const save = async (row: SystemConfig) => {
    try {
      const updated = await api.updateSetting(row.key, values[row.key] ?? row.value, row.description)
      setRows((prev) => prev.map((r) => (r.key === row.key ? updated : r)))
      setToast(`Đã cập nhật ${row.key}`)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Cập nhật thất bại')
    }
  }

  return (
    <Box>
      <Typography variant="h3" sx={{ mb: 1 }}>Cấu hình hệ thống</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Lấy ý tưởng từ bảng System_config trong dự án bãi đỗ xe: admin có thể chỉnh phí giao hàng, thuế, giờ mở cửa và trạng thái nhận đơn mà không sửa code.
      </Typography>
      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}
      <Stack spacing={2}>
        {rows.map((row) => (
          <Paper key={row.key} variant="outlined" sx={{ p: 2 }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems={{ md: 'center' }}>
              <Box sx={{ flex: 1 }}>
                <Typography className="mono" sx={{ fontWeight: 700 }}>{row.key}</Typography>
                <Typography variant="body2" color="text.secondary">{row.description}</Typography>
              </Box>
              <TextField
                size="small"
                label="Giá trị"
                value={values[row.key] ?? ''}
                onChange={(e) => setValues((v) => ({ ...v, [row.key]: e.target.value }))}
                sx={{ minWidth: 240 }}
              />
              <Button variant="contained" onClick={() => save(row)}>Lưu</Button>
            </Stack>
          </Paper>
        ))}
      </Stack>
      <Snackbar open={!!toast} autoHideDuration={2500} onClose={() => setToast('')} message={toast} />
    </Box>
  )
}
