import { useEffect, useState } from 'react'
import { Alert, Box, MenuItem, Select, Snackbar, Typography } from '@mui/material'
import { DataGrid, type GridColDef } from '@mui/x-data-grid'
import { api, money } from '../../api/client'
import StatusChip from '../../components/StatusChip'
import { ORDER_STATUSES, type AdminOrder, type OrderStatus } from '../../types'
import { useAuth } from '../../auth/AuthContext'

export default function AdminOrdersPage() {
  const { user } = useAuth()
  const [orders, setOrders] = useState<AdminOrder[]>([])
  const [error, setError] = useState('')
  const [toast, setToast] = useState('')

  const load = () => {
    const loader = user?.role === 'admin' ? api.allOrders : api.staffOrders
    loader()
      .then(setOrders)
      .catch((e) => setError(e instanceof Error ? e.message : 'Không tải được đơn hàng'))
  }

  useEffect(() => {
    load()
  }, [user?.role])

  const changeStatus = async (orderId: number, status: OrderStatus) => {
    try {
      const updated = await api.updateStatus(orderId, status)
      setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status: updated.status } : o)))
      setToast(`Đơn #${orderId} → ${status}`)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Cập nhật thất bại')
    }
  }

  const columns: GridColDef<AdminOrder>[] = [
    {
      field: 'order_code',
      headerName: 'Mã đơn',
      width: 170,
      renderCell: (p) => <span className="mono">{p.row.order_code ?? `#${String(p.row.id).padStart(4, '0')}`}</span>,
    },
    { field: 'customer', headerName: 'Khách hàng', flex: 1, valueGetter: (_v, row) => row.user.name },
    { field: 'email', headerName: 'Email', flex: 1, valueGetter: (_v, row) => row.user.email },
    {
      field: 'items',
      headerName: 'Số món',
      width: 90,
      valueGetter: (_v, row) => row.items.reduce((s, i) => s + i.quantity, 0),
    },
    {
      field: 'payment',
      headerName: 'Thanh toán',
      width: 170,
      valueGetter: (_v, row) => row.payment ? `${row.payment.method}/${row.payment.status}` : '—',
    },
    {
      field: 'total',
      headerName: 'Tổng',
      width: 140,
      renderCell: (p) => <span className="mono">{money(p.row.total)}</span>,
    },
    {
      field: 'created_at',
      headerName: 'Thời gian',
      width: 170,
      valueFormatter: (v) => new Date(v as string).toLocaleString('vi-VN'),
    },
    {
      field: 'status',
      headerName: 'Trạng thái',
      width: 230,
      sortable: false,
      renderCell: (p) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, height: '100%' }}>
          <StatusChip status={p.row.status} />
          <Select
            size="small"
            variant="standard"
            value={p.row.status}
            onChange={(e) => changeStatus(p.row.id, e.target.value as OrderStatus)}
            sx={{ fontSize: 13 }}
          >
            {ORDER_STATUSES.map((s) => (
              <MenuItem key={s} value={s}>
                {s}
              </MenuItem>
            ))}
          </Select>
        </Box>
      ),
    },
  ]

  return (
    <Box>
      <Typography variant="h3" sx={{ mb: 1 }}>
        Order board
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Admin xem toàn bộ đơn; kitchen staff thấy hàng chờ bếp; delivery staff thấy các đơn sẵn sàng giao/hoàn tất.
      </Typography>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}
      <Box sx={{ bgcolor: 'background.paper' }}>
        <DataGrid
          rows={orders}
          columns={columns}
          getRowId={(r) => r.id}
          autoHeight
          disableRowSelectionOnClick
          initialState={{
            pagination: { paginationModel: { pageSize: 10 } },
            sorting: { sortModel: [{ field: 'id', sort: 'desc' }] },
          }}
          pageSizeOptions={[10, 25, 50]}
        />
      </Box>
      <Snackbar
        open={!!toast}
        autoHideDuration={2500}
        onClose={() => setToast('')}
        message={toast}
      />
    </Box>
  )
}
