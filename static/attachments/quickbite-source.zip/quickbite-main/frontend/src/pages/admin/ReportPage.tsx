import { useEffect, useMemo, useState } from 'react'
import {
  Alert,
  Box,
  Button,
  MenuItem,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material'
import { BarChart } from '@mui/x-charts/BarChart'
import { PieChart } from '@mui/x-charts/PieChart'
import { api, money } from '../../api/client'
import MetricCard from '../../components/MetricCard'
import type { DailyRevenueRow, StatusCounts, TopItemRow } from '../../types'

export default function ReportPage() {
  const [rows, setRows] = useState<DailyRevenueRow[]>([])
  const [topItems, setTopItems] = useState<TopItemRow[]>([])
  const [statusCounts, setStatusCounts] = useState<StatusCounts>({})
  const [days, setDays] = useState(14)
  const [error, setError] = useState('')

  useEffect(() => {
    setError('')
    Promise.all([api.dailyRevenue(days), api.topItems(10), api.statusCounts()])
      .then(([daily, top, status]) => {
        setRows(daily)
        setTopItems(top)
        setStatusCounts(status)
      })
      .catch((e) => setError(e instanceof Error ? e.message : 'Không tải được báo cáo'))
  }, [days])

  const totalRevenue = rows.reduce((s, r) => s + r.revenue, 0)
  const totalOrders = rows.reduce((s, r) => s + r.order_count, 0)
  const aov = totalOrders ? totalRevenue / totalOrders : 0

  const pieData = useMemo(
    () => Object.entries(statusCounts).map(([label, value], id) => ({ id, label, value })),
    [statusCounts],
  )

  const exportCsv = async (type: 'orders' | 'revenue' | 'items') => {
    try {
      await api.exportReport(type)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Không xuất được CSV')
    }
  }

  return (
    <Box>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 3 }}>
        <Typography variant="h3">Báo cáo kinh doanh</Typography>
        <Stack direction="row" spacing={1} alignItems="center">
          <Button variant="outlined" onClick={() => exportCsv('orders')}>CSV đơn</Button>
          <Button variant="outlined" onClick={() => exportCsv('revenue')}>CSV doanh thu</Button>
          <Button variant="outlined" onClick={() => exportCsv('items')}>CSV món</Button>
          <TextField
            select
            size="small"
            label="Khoảng ngày"
            value={days}
            onChange={(e) => setDays(Number(e.target.value))}
            sx={{ width: 170 }}
          >
            {[7, 14, 30, 90].map((d) => (
              <MenuItem key={d} value={d}>
                {d} ngày gần nhất
              </MenuItem>
            ))}
          </TextField>
        </Stack>
      </Stack>

      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Dữ liệu được đọc từ các SQL view <code>v_daily_revenue</code>, <code>v_item_sales</code> và{' '}
        <code>v_order_status_counts</code>.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr 1fr' }, gap: 2, mb: 3 }}>
        <MetricCard label="Tổng doanh thu" value={money(totalRevenue)} />
        <MetricCard label="Tổng số đơn" value={totalOrders} />
        <MetricCard label="AOV / Giá trị đơn TB" value={money(aov)} />
      </Box>

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: '2fr 1fr' }, gap: 2, mb: 3 }}>
        <Paper variant="outlined" sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Doanh thu theo ngày
          </Typography>
          {rows.length ? (
            <BarChart
              height={320}
              xAxis={[{ scaleType: 'band', data: rows.map((r) => r.day) }]}
              series={[{ data: rows.map((r) => r.revenue), label: 'Doanh thu' }]}
            />
          ) : (
            <Typography color="text.secondary">Chưa có dữ liệu trong kỳ này.</Typography>
          )}
        </Paper>

        <Paper variant="outlined" sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Số đơn theo trạng thái
          </Typography>
          {pieData.length ? (
            <PieChart series={[{ data: pieData, innerRadius: 35 }]} height={320} />
          ) : (
            <Typography color="text.secondary">Chưa có dữ liệu trạng thái.</Typography>
          )}
        </Paper>
      </Box>

      <Paper variant="outlined" sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Top món bán chạy
        </Typography>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Món ăn</TableCell>
              <TableCell align="right">Số lượng bán</TableCell>
              <TableCell align="right">Doanh thu</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {topItems.map((item) => (
              <TableRow key={item.name}>
                <TableCell>{item.name}</TableCell>
                <TableCell align="right" className="mono">
                  {item.sold}
                </TableCell>
                <TableCell align="right" className="mono">
                  {money(item.revenue)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  )
}
