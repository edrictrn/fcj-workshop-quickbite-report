import { useEffect, useMemo, useState } from 'react'
import {
  Alert,
  Avatar,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  MenuItem,
  Snackbar,
  Stack,
  Switch,
  TextField,
  Typography,
} from '@mui/material'
import {
  DataGrid,
  GridActionsCellItem,
  type GridColDef,
  type GridRowParams,
} from '@mui/x-data-grid'
import AddIcon from '@mui/icons-material/Add'
import EditIcon from '@mui/icons-material/Edit'
import DeleteIcon from '@mui/icons-material/Delete'
import CategoryIcon from '@mui/icons-material/Category'
import RestaurantIcon from '@mui/icons-material/Restaurant'
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import { api, money } from '../../api/client'
import type { Category, Item, ItemPayload } from '../../types'

interface FormState {
  name: string
  description: string
  price: string
  category_id: number | ''
  is_available: boolean
  image_url: string
}

const EMPTY_FORM: FormState = {
  name: '',
  description: '',
  price: '',
  category_id: '',
  is_available: true,
  image_url: '',
}

export default function MenuAdminPage() {
  const [items, setItems] = useState<Item[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [error, setError] = useState('')
  const [toast, setToast] = useState('')

  // item dialog
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<Item | null>(null)
  const [form, setForm] = useState<FormState>(EMPTY_FORM)
  const [formError, setFormError] = useState('')
  const [saving, setSaving] = useState(false)

  // delete confirm
  const [toDelete, setToDelete] = useState<Item | null>(null)

  // image upload
  const [uploading, setUploading] = useState(false)

  // category dialog
  const [catOpen, setCatOpen] = useState(false)
  const [catName, setCatName] = useState('')

  const load = () => {
    api
      .adminItems()
      .then(setItems)
      .catch((e) => setError(e instanceof Error ? e.message : 'Không tải được danh sách món'))
    api.categories().then(setCategories).catch(() => undefined)
  }

  useEffect(() => {
    load()
  }, [])

  const openAdd = () => {
    setEditing(null)
    setForm(EMPTY_FORM)
    setFormError('')
    setDialogOpen(true)
  }

  const openEdit = (item: Item) => {
    setEditing(item)
    setForm({
      name: item.name,
      description: item.description ?? '',
      price: String(item.price),
      category_id: item.category?.id ?? '',
      is_available: item.is_available,
      image_url: item.image_url ?? '',
    })
    setFormError('')
    setDialogOpen(true)
  }

  const save = async () => {
    const price = Number(form.price)
    if (form.name.trim().length < 2) return setFormError('Tên món tối thiểu 2 ký tự.')
    if (!form.category_id) return setFormError('Hãy chọn danh mục.')
    if (!Number.isFinite(price) || price <= 0) return setFormError('Giá phải là số dương.')

    const payload: ItemPayload = {
      name: form.name.trim(),
      description: form.description.trim() || null,
      price,
      category_id: Number(form.category_id),
      is_available: form.is_available,
      image_url: form.image_url.trim() || null,
    }

    setSaving(true)
    setFormError('')
    try {
      if (editing) {
        await api.updateItem(editing.id, payload)
        setToast(`Đã cập nhật "${payload.name}"`)
      } else {
        await api.createItem(payload)
        setToast(`Đã thêm "${payload.name}"`)
      }
      setDialogOpen(false)
      load()
    } catch (e) {
      setFormError(e instanceof Error ? e.message : 'Lưu thất bại')
    } finally {
      setSaving(false)
    }
  }

  const confirmDelete = async () => {
    if (!toDelete) return
    try {
      await api.deleteItem(toDelete.id)
      setToast(`Đã ẩn món "${toDelete.name}" khỏi menu bán hàng`)
      load()
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Ẩn món thất bại')
    } finally {
      setToDelete(null)
    }
  }

  const handleUpload = async (fileList: FileList | null) => {
    const file = fileList?.[0]
    if (!file) return
    setUploading(true)
    setFormError('')
    try {
      const { url } = await api.uploadImage(file)
      setForm((f) => ({ ...f, image_url: url }))
      setToast('Đã upload ảnh lên S3')
    } catch (e) {
      setFormError(e instanceof Error ? e.message : 'Upload ảnh thất bại')
    } finally {
      setUploading(false)
    }
  }

  const createCategory = async () => {
    if (catName.trim().length < 2) return
    try {
      const cat = await api.createCategory(catName.trim())
      setCategories((prev) => [...prev, cat].sort((a, b) => a.name.localeCompare(b.name)))
      setForm((f) => ({ ...f, category_id: cat.id }))
      setToast(`Đã thêm danh mục "${cat.name}"`)
      setCatName('')
      setCatOpen(false)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Thêm danh mục thất bại')
    }
  }

  const columns: GridColDef<Item>[] = useMemo(
    () => [
      { field: 'id', headerName: 'ID', width: 70 },
      {
        field: 'image_url',
        headerName: '',
        width: 64,
        sortable: false,
        filterable: false,
        renderCell: (p) =>
          p.value ? (
            <Avatar variant="rounded" src={p.value as string} sx={{ width: 40, height: 40 }} />
          ) : (
            <Avatar variant="rounded" sx={{ width: 40, height: 40, bgcolor: 'action.hover' }}>
              <RestaurantIcon fontSize="small" color="disabled" />
            </Avatar>
          ),
      },
      { field: 'name', headerName: 'Tên món', flex: 1, minWidth: 160 },
      {
        field: 'category',
        headerName: 'Danh mục',
        width: 150,
        valueGetter: (_v, row) => row.category?.name ?? '—',
      },
      {
        field: 'price',
        headerName: 'Giá',
        width: 130,
        renderCell: (p) => <span className="mono">{money(p.row.price)}</span>,
      },
      {
        field: 'is_available',
        headerName: 'Đang bán',
        width: 110,
        type: 'boolean',
      },
      {
        field: 'actions',
        type: 'actions',
        headerName: '',
        width: 90,
        getActions: (params: GridRowParams<Item>) => [
          <GridActionsCellItem
            key="edit"
            icon={<EditIcon />}
            label="Sửa"
            onClick={() => openEdit(params.row)}
          />,
          <GridActionsCellItem
            key="delete"
            icon={<DeleteIcon />}
            label="Ẩn món"
            onClick={() => setToDelete(params.row)}
            showInMenu={false}
          />,
        ],
      },
    ],
    [],
  )

  return (
    <Box>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 3 }}>
        <Typography variant="h3">Quản lý món ăn</Typography>
        <Stack direction="row" spacing={1}>
          <Button variant="outlined" startIcon={<CategoryIcon />} onClick={() => setCatOpen(true)}>
            Thêm danh mục
          </Button>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openAdd}>
            Thêm món
          </Button>
        </Stack>
      </Stack>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}

      <Box sx={{ bgcolor: 'background.paper' }}>
        <DataGrid
          rows={items}
          columns={columns}
          getRowId={(r) => r.id}
          autoHeight
          disableRowSelectionOnClick
          initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
          pageSizeOptions={[10, 25, 50]}
        />
      </Box>

      {/* Add / Edit item dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} fullWidth maxWidth="sm">
        <DialogTitle>{editing ? 'Sửa món' : 'Thêm món mới'}</DialogTitle>
        <DialogContent>
          {formError && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {formError}
            </Alert>
          )}
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="Tên món"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              fullWidth
            />
            <TextField
              label="Mô tả"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              multiline
              minRows={2}
              fullWidth
            />
            <Stack direction="row" spacing={2}>
              <TextField
                label="Giá (VND)"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                type="number"
                fullWidth
              />
              <TextField
                label="Danh mục"
                select
                value={form.category_id}
                onChange={(e) => setForm({ ...form, category_id: Number(e.target.value) })}
                fullWidth
              >
                {categories.map((c) => (
                  <MenuItem key={c.id} value={c.id}>
                    {c.name}
                  </MenuItem>
                ))}
              </TextField>
            </Stack>
            <Stack direction="row" spacing={1} alignItems="flex-start">
              <TextField
                label="Ảnh (URL)"
                value={form.image_url}
                onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                placeholder="Dán URL hoặc upload lên S3"
                fullWidth
              />
              <Button
                component="label"
                variant="outlined"
                startIcon={<CloudUploadIcon />}
                disabled={uploading}
                sx={{ whiteSpace: 'nowrap', mt: 0.5 }}
              >
                {uploading ? '…' : 'Upload'}
                <input
                  hidden
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={(e) => handleUpload(e.target.files)}
                />
              </Button>
            </Stack>
            {form.image_url && (
              <Box
                component="img"
                src={form.image_url}
                alt="preview"
                sx={{ width: '100%', maxHeight: 160, objectFit: 'cover', borderRadius: 1 }}
              />
            )}
            <FormControlLabel
              control={
                <Switch
                  checked={form.is_available}
                  onChange={(e) => setForm({ ...form, is_available: e.target.checked })}
                />
              }
              label="Đang bán"
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Hủy</Button>
          <Button variant="contained" onClick={save} disabled={saving}>
            {saving ? 'Đang lưu…' : 'Lưu'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete confirm */}
      <Dialog open={!!toDelete} onClose={() => setToDelete(null)}>
        <DialogTitle>Ẩn món?</DialogTitle>
        <DialogContent>
          <Typography>
            Bạn có chắc muốn ẩn <strong>{toDelete?.name}</strong> khỏi menu bán hàng không? Món sẽ không còn hiển thị với customer nhưng dữ liệu đơn hàng cũ vẫn được giữ.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setToDelete(null)}>Hủy</Button>
          <Button color="error" variant="contained" onClick={confirmDelete}>
            Ẩn món
          </Button>
        </DialogActions>
      </Dialog>

      {/* Add category */}
      <Dialog open={catOpen} onClose={() => setCatOpen(false)} fullWidth maxWidth="xs">
        <DialogTitle>Thêm danh mục</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            label="Tên danh mục"
            value={catName}
            onChange={(e) => setCatName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && createCategory()}
            fullWidth
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCatOpen(false)}>Hủy</Button>
          <Button variant="contained" onClick={createCategory}>
            Thêm
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={!!toast}
        autoHideDuration={2500}
        onClose={() => setToast('')}
        message={toast}
      />
    </Box>
  )
}
