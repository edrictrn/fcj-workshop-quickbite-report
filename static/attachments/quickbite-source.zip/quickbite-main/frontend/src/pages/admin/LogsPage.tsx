import { useEffect, useState } from 'react'
import { Alert, Box, Paper, Typography } from '@mui/material'
import { DataGrid, type GridColDef } from '@mui/x-data-grid'
import { api } from '../../api/client'
import type { OperationLog } from '../../types'

export default function LogsPage() {
  const [rows, setRows] = useState<OperationLog[]>([])
  const [error, setError] = useState('')

  useEffect(() => {
    api.operationLogs(200)
      .then(setRows)
      .catch((e) => setError(e instanceof Error ? e.message : 'Không tải được audit logs'))
  }, [])

  const columns: GridColDef<OperationLog>[] = [
    { field: 'id', headerName: 'ID', width: 70 },
    { field: 'created_at', headerName: 'Thời gian', width: 180, valueFormatter: (v) => new Date(v as string).toLocaleString('vi-VN') },
    { field: 'actor_email', headerName: 'Người thao tác', flex: 1, minWidth: 180 },
    { field: 'actor_role', headerName: 'Vai trò', width: 140 },
    { field: 'action', headerName: 'Hành động', width: 170 },
    { field: 'target_type', headerName: 'Đối tượng', width: 130 },
    { field: 'target_id', headerName: 'Mã', width: 130 },
    { field: 'detail', headerName: 'Chi tiết', flex: 1.5, minWidth: 240 },
  ]

  return (
    <Box>
      <Typography variant="h3" sx={{ mb: 1 }}>Audit logs</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Ghi lại thao tác quản trị như sửa món, đổi trạng thái đơn, upload ảnh, cập nhật cấu hình và thanh toán mock.
      </Typography>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      <Paper variant="outlined">
        <DataGrid
          rows={rows}
          columns={columns}
          getRowId={(r) => r.id}
          autoHeight
          disableRowSelectionOnClick
          initialState={{ pagination: { paginationModel: { pageSize: 10 } }, sorting: { sortModel: [{ field: 'id', sort: 'desc' }] } }}
          pageSizeOptions={[10, 25, 50]}
        />
      </Paper>
    </Box>
  )
}
