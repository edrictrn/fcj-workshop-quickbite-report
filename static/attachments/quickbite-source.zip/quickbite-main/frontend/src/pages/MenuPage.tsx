import { useEffect, useMemo, useState } from 'react'
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CardMedia,
  IconButton,
  InputAdornment,
  MenuItem,
  Snackbar,
  Stack,
  TextField,
  Typography,
} from '@mui/material'
import SearchIcon from '@mui/icons-material/Search'
import AddIcon from '@mui/icons-material/Add'
import RemoveIcon from '@mui/icons-material/Remove'
import RestartAltIcon from '@mui/icons-material/RestartAlt'
import { useNavigate } from 'react-router-dom'
import { api, money } from '../api/client'
import { useAuth } from '../auth/AuthContext'
import type { CartLine, Category, Item, MenuQuery, PaymentMethod, SystemConfig } from '../types'

const FALLBACK_IMG = 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800'

export default function MenuPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [items, setItems] = useState<Item[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [search, setSearch] = useState('')
  const [categoryId, setCategoryId] = useState<number | ''>('')
  const [minPrice, setMinPrice] = useState('')
  const [maxPrice, setMaxPrice] = useState('')
  const [sortBy, setSortBy] = useState<MenuQuery['sort_by']>('name')
  const [sortOrder, setSortOrder] = useState<MenuQuery['sort_order']>('asc')
  const [cart, setCart] = useState<Map<number, CartLine>>(new Map())
  const [note, setNote] = useState('')
  const [error, setError] = useState('')
  const [toast, setToast] = useState('')
  const [settings, setSettings] = useState<SystemConfig[]>([])
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod')

  const buildParams = (): MenuQuery => ({
    search: search.trim(),
    category_id: categoryId,
    min_price: minPrice ? Number(minPrice) : '',
    max_price: maxPrice ? Number(maxPrice) : '',
    sort_by: sortBy,
    sort_order: sortOrder,
  })

  const loadMenu = () => {
    api
      .menu(buildParams())
      .then(setItems)
      .catch((e) => setError(e instanceof Error ? e.message : 'Không tải được menu'))
  }

  useEffect(() => {
    loadMenu()
    api.categories().then(setCategories).catch(() => undefined)
    api.publicSettings().then(setSettings).catch(() => undefined)
  }, [])

  const resetFilters = () => {
    setSearch('')
    setCategoryId('')
    setMinPrice('')
    setMaxPrice('')
    setSortBy('name')
    setSortOrder('asc')
    api.menu({ sort_by: 'name', sort_order: 'asc' }).then(setItems).catch(() => undefined)
  }

  const changeQty = (item: Item, delta: number) => {
    setCart((prev) => {
      const next = new Map(prev)
      const line = next.get(item.id) ?? { item, quantity: 0 }
      const quantity = line.quantity + delta
      if (quantity <= 0) next.delete(item.id)
      else next.set(item.id, { item, quantity })
      return next
    })
  }

  const cartLines = useMemo(() => [...cart.values()], [cart])
  const cartSubtotal = useMemo(
    () => cartLines.reduce((sum, l) => sum + l.item.price * l.quantity, 0),
    [cartLines],
  )
  const settingMap = useMemo(() => Object.fromEntries(settings.map((s) => [s.key, s.value])), [settings])
  const deliveryFee = Number(settingMap.delivery_fee ?? 0) || 0
  const taxRate = Number(settingMap.tax_rate ?? 0) || 0
  const minOrderValue = Number(settingMap.min_order_value ?? 0) || 0
  const restaurantOpen = (settingMap.restaurant_open ?? 'true').toLowerCase() === 'true'
  const cartTotal = useMemo(
    () => (cartSubtotal ? cartSubtotal + deliveryFee + cartSubtotal * taxRate : 0),
    [cartSubtotal, deliveryFee, taxRate],
  )

  const createOrder = async () => {
    if (!user) {
      navigate('/login')
      return
    }
    if (!cart.size) return
    try {
      const payload = cartLines.map((l) => ({ item_id: l.item.id, quantity: l.quantity }))
      const order = await api.createOrder(payload, note.trim() || null, paymentMethod)
      setCart(new Map())
      setNote('')
      setToast(`Đã tạo đơn ${order.order_code ?? '#' + order.id} · ${order.payment?.status ?? ''}`)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Tạo đơn thất bại')
    }
  }

  return (
    <Box>
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={3} alignItems="flex-start">
        <Box sx={{ flex: 1, width: '100%' }}>
          <Stack
            direction={{ xs: 'column', sm: 'row' }}
            justifyContent="space-between"
            alignItems={{ sm: 'center' }}
            spacing={2}
            sx={{ mb: 2 }}
          >
            <Typography variant="h3">Menu hôm nay</Typography>
            <TextField
              size="small"
              placeholder="Tìm món…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && loadMenu()}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon fontSize="small" />
                  </InputAdornment>
                ),
              }}
            />
          </Stack>

          <Card variant="outlined" sx={{ p: 2, mb: 3 }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.5}>
              <TextField
                select
                size="small"
                label="Danh mục"
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value === '' ? '' : Number(e.target.value))}
                sx={{ minWidth: 150 }}
              >
                <MenuItem value="">Tất cả</MenuItem>
                {categories.map((c) => (
                  <MenuItem key={c.id} value={c.id}>
                    {c.name}
                  </MenuItem>
                ))}
              </TextField>
              <TextField
                size="small"
                label="Giá từ"
                type="number"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
              />
              <TextField
                size="small"
                label="Giá đến"
                type="number"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
              />
              <TextField
                select
                size="small"
                label="Sắp xếp"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as MenuQuery['sort_by'])}
                sx={{ minWidth: 130 }}
              >
                <MenuItem value="name">Tên món</MenuItem>
                <MenuItem value="price">Giá</MenuItem>
              </TextField>
              <TextField
                select
                size="small"
                label="Thứ tự"
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value as MenuQuery['sort_order'])}
                sx={{ minWidth: 120 }}
              >
                <MenuItem value="asc">Tăng dần</MenuItem>
                <MenuItem value="desc">Giảm dần</MenuItem>
              </TextField>
              <Button variant="contained" onClick={loadMenu}>
                Lọc
              </Button>
              <Button variant="outlined" startIcon={<RestartAltIcon />} onClick={resetFilters}>
                Reset
              </Button>
            </Stack>
          </Card>

          {error && (
            <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
              {error}
            </Alert>
          )}

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', lg: '1fr 1fr 1fr' },
              gap: 2,
            }}
          >
            {items.map((item) => (
              <Card key={item.id} variant="outlined" sx={{ display: 'flex', flexDirection: 'column' }}>
                <CardMedia component="img" height="140" image={item.image_url || FALLBACK_IMG} alt={item.name} />
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography variant="caption" color="primary" sx={{ fontWeight: 600 }}>
                    {item.category?.name ?? 'Khác'}
                  </Typography>
                  <Typography variant="h6" sx={{ lineHeight: 1.2 }}>
                    {item.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ minHeight: 40 }}>
                    {item.description}
                  </Typography>
                </CardContent>
                <Box sx={{ px: 2, pb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography className="mono" sx={{ fontWeight: 700 }}>
                    {money(item.price)}
                  </Typography>
                  <Button size="small" variant="contained" startIcon={<AddIcon />} onClick={() => changeQty(item, 1)}>
                    Thêm
                  </Button>
                </Box>
              </Card>
            ))}
          </Box>
          {!items.length && !error && <Typography color="text.secondary">Không có món phù hợp.</Typography>}
        </Box>

        <Card variant="outlined" sx={{ width: { xs: '100%', md: 320 }, position: { md: 'sticky' }, top: 88, flexShrink: 0 }}>
          <CardContent>
            <Typography variant="h5" gutterBottom>
              Giỏ hàng
            </Typography>
            {!cartLines.length ? (
              <Typography color="text.secondary" variant="body2">
                Chưa có món nào. Chọn món từ menu để bắt đầu.
              </Typography>
            ) : (
              <Stack spacing={1.5}>
                {cartLines.map((line) => (
                  <Stack key={line.item.id} direction="row" justifyContent="space-between" alignItems="center">
                    <Box sx={{ minWidth: 0 }}>
                      <Typography variant="body2" noWrap sx={{ fontWeight: 600 }}>
                        {line.item.name}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" className="mono">
                        {money(line.item.price)}
                      </Typography>
                    </Box>
                    <Stack direction="row" alignItems="center">
                      <IconButton size="small" onClick={() => changeQty(line.item, -1)}>
                        <RemoveIcon fontSize="small" />
                      </IconButton>
                      <Typography className="mono" sx={{ width: 20, textAlign: 'center' }}>
                        {line.quantity}
                      </Typography>
                      <IconButton size="small" onClick={() => changeQty(line.item, 1)}>
                        <AddIcon fontSize="small" />
                      </IconButton>
                    </Stack>
                  </Stack>
                ))}
                <TextField
                  select
                  size="small"
                  label="Thanh toán"
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                >
                  <MenuItem value="cod">COD / Trả khi nhận món</MenuItem>
                  <MenuItem value="mock_ewallet">Mock e-wallet</MenuItem>
                </TextField>
                <TextField
                  size="small"
                  placeholder="Ghi chú đơn hàng"
                  multiline
                  minRows={2}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                />
                <Stack spacing={0.5} sx={{ pt: 1 }}>
                  <Stack direction="row" justifyContent="space-between">
                    <Typography color="text.secondary">Tạm tính</Typography>
                    <Typography className="mono">{money(cartSubtotal)}</Typography>
                  </Stack>
                  <Stack direction="row" justifyContent="space-between">
                    <Typography color="text.secondary">Phí dịch vụ</Typography>
                    <Typography className="mono">{money(deliveryFee)}</Typography>
                  </Stack>
                  {taxRate > 0 && (
                    <Stack direction="row" justifyContent="space-between">
                      <Typography color="text.secondary">Thuế</Typography>
                      <Typography className="mono">{money(cartSubtotal * taxRate)}</Typography>
                    </Stack>
                  )}
                  {minOrderValue > 0 && cartSubtotal < minOrderValue && (
                    <Typography variant="caption" color="error">
                      Cần tối thiểu {money(minOrderValue)} để đặt đơn.
                    </Typography>
                  )}
                  <Typography variant="caption" color={restaurantOpen ? 'text.secondary' : 'error'}>
                    {restaurantOpen
                      ? `Giờ mở cửa: ${settingMap.restaurant_open_time ?? '07:00'} - ${settingMap.restaurant_close_time ?? '21:30'}`
                      : 'Nhà hàng đang tạm ngưng nhận đơn'}
                  </Typography>
                  <Stack direction="row" justifyContent="space-between" sx={{ pt: 1 }}>
                    <Typography sx={{ fontWeight: 700 }}>Tổng</Typography>
                    <Typography className="mono" sx={{ fontWeight: 700 }}>
                      {money(cartTotal)}
                    </Typography>
                  </Stack>
                </Stack>
                <Button variant="contained" size="large" onClick={createOrder} disabled={!restaurantOpen || cartSubtotal < minOrderValue}>
                  Đặt đơn
                </Button>
              </Stack>
            )}
          </CardContent>
        </Card>
      </Stack>

      <Snackbar
        open={!!toast}
        autoHideDuration={3000}
        onClose={() => setToast('')}
        message={toast}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
    </Box>
  )
}
