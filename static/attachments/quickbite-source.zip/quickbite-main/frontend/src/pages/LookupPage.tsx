import { useEffect, useState } from 'react'
import { Alert, Box, Button, Paper, Stack, TextField, Typography } from '@mui/material'
import { useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import OrderTicket from '../components/OrderTicket'
import StatusHistoryLog from '../components/StatusHistoryLog'
import type { Order } from '../types'

export default function LookupPage() {
  const [searchParams] = useSearchParams()
  const [code, setCode] = useState(searchParams.get('code') ?? '')
  const [token, setToken] = useState(searchParams.get('token') ?? '')
  const [order, setOrder] = useState<Order | null>(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (c = code, t = token) => {
    if (!c.trim() || !t.trim()) {
      setError('Cần cả mã đơn và mã tra cứu.')
      return
    }
    setBusy(true)
    setError('')
    setOrder(null)
    try {
      setOrder(await api.lookupOrder(c.trim(), t.trim()))
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Không tra cứu được đơn hàng')
    } finally {
      setBusy(false)
    }
  }

  // Auto-lookup when both values arrive via a shared tracking link.
  useEffect(() => {
    const c = searchParams.get('code') ?? ''
    const t = searchParams.get('token') ?? ''
    if (c && t) submit(c, t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <Box sx={{ maxWidth: 760, mx: 'auto' }}>
      <Typography variant="h3" sx={{ mb: 1 }}>
        Tra cứu đơn hàng
      </Typography>
      <Typography color="text.secondary" sx={{ mb: 3 }}>
        Nhập mã đơn (vd <code>QB-20260610-0010</code>) và mã tra cứu đi kèm đơn để xem trạng thái.
      </Typography>
      <Paper variant="outlined" sx={{ p: 3, mb: 3 }}>
        <Stack spacing={1.5}>
          <TextField
            fullWidth
            label="Mã đơn hàng"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
          />
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
            <TextField
              fullWidth
              label="Mã tra cứu (token)"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submit()}
            />
            <Button variant="contained" onClick={() => submit()} disabled={busy} sx={{ minWidth: 120 }}>
              {busy ? 'Đang tìm…' : 'Tra cứu'}
            </Button>
          </Stack>
        </Stack>
      </Paper>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {order && (
        <Stack spacing={3}>
          <OrderTicket order={order} showTimeline />
          <Paper variant="outlined" sx={{ p: 3 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Lịch sử trạng thái</Typography>
            <StatusHistoryLog history={order.status_history} />
          </Paper>
        </Stack>
      )}
    </Box>
  )
}
