import { useState } from 'react'
import {
  Alert,
  Box,
  Button,
  Link,
  Paper,
  Stack,
  TextField,
  Typography,
} from '@mui/material'
import { Link as RouterLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'

export default function RegisterPage() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async () => {
    setError('')
    if (name.trim().length < 2) return setError('Tên tối thiểu 2 ký tự.')
    if (password.length < 6) return setError('Mật khẩu tối thiểu 6 ký tự.')
    if (password !== confirm) return setError('Mật khẩu nhập lại không khớp.')

    setBusy(true)
    try {
      await register(name.trim(), email.trim(), password)
      navigate('/menu')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Đăng ký thất bại')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Box sx={{ display: 'grid', placeItems: 'center', minHeight: '70vh' }}>
      <Paper variant="outlined" sx={{ p: 4, width: '100%', maxWidth: 440 }}>
        <Typography variant="h4" gutterBottom>
          Tạo tài khoản
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Đăng ký tài khoản customer để đặt món và xem lịch sử đơn hàng.
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <Stack spacing={2}>
          <TextField label="Họ tên" value={name} onChange={(e) => setName(e.target.value)} fullWidth />
          <TextField label="Email" value={email} onChange={(e) => setEmail(e.target.value)} fullWidth />
          <TextField
            label="Mật khẩu"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            fullWidth
          />
          <TextField
            label="Nhập lại mật khẩu"
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
            fullWidth
          />
          <Button variant="contained" size="large" onClick={submit} disabled={busy}>
            {busy ? 'Đang tạo tài khoản…' : 'Đăng ký'}
          </Button>
          <Typography variant="body2" color="text.secondary" textAlign="center">
            Đã có tài khoản?{' '}
            <Link component={RouterLink} to="/login">
              Đăng nhập
            </Link>
          </Typography>
        </Stack>
      </Paper>
    </Box>
  )
}
