import { useCallback, useEffect, useState } from 'react'
import { Alert, Box, IconButton, Link as MuiLink, Snackbar, Stack, Tooltip, Typography } from '@mui/material'
import ContentCopyIcon from '@mui/icons-material/ContentCopy'
import { Link as RouterLink } from 'react-router-dom'
import { api } from '../api/client'
import type { Order } from '../types'
import OrderTicket from '../components/OrderTicket'

export default function MyOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [error, setError] = useState('')
  const [payingId, setPayingId] = useState<number | null>(null)
  const [toast, setToast] = useState('')

  const load = useCallback(() => {
    api
      .myOrders()
      .then(setOrders)
      .catch((e) => setError(e instanceof Error ? e.message : 'Không tải được đơn hàng'))
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const handlePay = async (order: Order) => {
    if (!order.payment) return
    setPayingId(order.id)
    try {
      await api.completeMockPayment(order.payment.id, true)
      setToast(`Đã thanh toán đơn ${order.order_code ?? order.id}`)
      load()
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Thanh toán thất bại')
    } finally {
      setPayingId(null)
    }
  }

  const copyTracking = (order: Order) => {
    if (!order.order_code || !order.lookup_token) return
    const link = `${window.location.origin}/lookup?code=${order.order_code}&token=${order.lookup_token}`
    navigator.clipboard?.writeText(link)
    setToast('Đã copy link tra cứu')
  }

  return (
    <Box>
      <Typography variant="h3" sx={{ mb: 3 }}>
        Đơn của tôi
      </Typography>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}
      {!orders.length && !error ? (
        <Typography color="text.secondary">
          Bạn chưa có đơn nào. Vào Menu để đặt món đầu tiên.
        </Typography>
      ) : (
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', lg: '1fr 1fr 1fr' },
            gap: 2,
          }}
        >
          {orders.map((order) => (
            <Stack key={order.id} spacing={1}>
              <OrderTicket
                order={order}
                showTimeline
                onPay={() => handlePay(order)}
                paying={payingId === order.id}
              />
              {order.order_code && (
                <Stack
                  direction="row"
                  alignItems="center"
                  justifyContent="space-between"
                  sx={{ px: 0.5 }}
                >
                  <MuiLink
                    component={RouterLink}
                    to={`/orders/${order.order_code}?token=${order.lookup_token ?? ''}`}
                    variant="caption"
                  >
                    Xem chi tiết →
                  </MuiLink>
                  <Tooltip title="Copy link tra cứu">
                    <IconButton size="small" onClick={() => copyTracking(order)}>
                      <ContentCopyIcon sx={{ fontSize: 15 }} />
                    </IconButton>
                  </Tooltip>
                </Stack>
              )}
            </Stack>
          ))}
        </Box>
      )}
      <Snackbar
        open={!!toast}
        autoHideDuration={2500}
        onClose={() => setToast('')}
        message={toast}
      />
    </Box>
  )
}
