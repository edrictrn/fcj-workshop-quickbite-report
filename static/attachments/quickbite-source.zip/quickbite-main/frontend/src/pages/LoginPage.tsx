import { useState } from 'react'
import {
  Alert,
  Box,
  Button,
  Link,
  Paper,
  Stack,
  TextField,
  Typography,
} from '@mui/material'
import { Link as RouterLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'

const DEMO = {
  customer: { email: 'customer@quickbite.com', password: 'Customer@123' },
  admin: { email: 'admin@quickbite.com', password: 'Admin@123' },
  kitchen: { email: 'kitchen@quickbite.com', password: 'Customer@123' },
  delivery: { email: 'delivery@quickbite.com', password: 'Customer@123' },
}

export default function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState(DEMO.customer.email)
  const [password, setPassword] = useState(DEMO.customer.password)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async () => {
    setBusy(true)
    setError('')
    try {
      await login(email.trim(), password)
      navigate('/menu')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Đăng nhập thất bại')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Box sx={{ display: 'grid', placeItems: 'center', minHeight: '70vh' }}>
      <Paper variant="outlined" sx={{ p: 4, width: '100%', maxWidth: 420 }}>
        <Typography variant="h4" gutterBottom>
          Đăng nhập
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Dùng tài khoản demo hoặc nhập thông tin của bạn.
        </Typography>

        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} sx={{ mb: 3 }}>
          {([
            ['Customer', DEMO.customer],
            ['Admin', DEMO.admin],
            ['Kitchen', DEMO.kitchen],
            ['Delivery', DEMO.delivery],
          ] as const).map(([label, account]) => (
            <Button
              key={label}
              fullWidth
              variant="outlined"
              onClick={() => {
                setEmail(account.email)
                setPassword(account.password)
              }}
            >
              {label}
            </Button>
          ))}
        </Stack>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <Stack spacing={2}>
          <TextField
            label="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            fullWidth
          />
          <TextField
            label="Mật khẩu"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
            fullWidth
          />
          <Button variant="contained" size="large" onClick={submit} disabled={busy}>
            {busy ? 'Đang đăng nhập…' : 'Đăng nhập'}
          </Button>
          <Typography variant="body2" color="text.secondary" textAlign="center">
            Chưa có tài khoản?{' '}
            <Link component={RouterLink} to="/register">
              Đăng ký
            </Link>
          </Typography>
        </Stack>
      </Paper>
    </Box>
  )
}
