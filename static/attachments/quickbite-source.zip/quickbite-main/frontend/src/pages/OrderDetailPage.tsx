import { useEffect, useState } from 'react'
import { Alert, Box, Button, Paper, Stack, TextField, Typography } from '@mui/material'
import { useParams, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import type { Order } from '../types'
import OrderTicket from '../components/OrderTicket'
import StatusHistoryLog from '../components/StatusHistoryLog'

export default function OrderDetailPage() {
  const { orderCode = '' } = useParams()
  const [searchParams] = useSearchParams()
  const [token, setToken] = useState(searchParams.get('token') ?? '')
  const [order, setOrder] = useState<Order | null>(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const fetchOrder = async (tk: string) => {
    if (!orderCode || !tk) return
    setBusy(true)
    setError('')
    try {
      setOrder(await api.lookupOrder(orderCode, tk))
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Không tải được đơn hàng')
    } finally {
      setBusy(false)
    }
  }

  useEffect(() => {
    const tk = searchParams.get('token') ?? ''
    if (tk) fetchOrder(tk)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderCode])

  return (
    <Box sx={{ maxWidth: 760, mx: 'auto' }}>
      <Typography variant="h3" sx={{ mb: 1 }}>
        Chi tiết đơn {orderCode}
      </Typography>

      {!order && (
        <Paper variant="outlined" sx={{ p: 3, mb: 3 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Nhập mã tra cứu (lookup token) đi kèm đơn để xem chi tiết.
          </Typography>
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
            <TextField
              fullWidth
              label="Mã tra cứu"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && fetchOrder(token)}
            />
            <Button variant="contained" onClick={() => fetchOrder(token)} disabled={busy}>
              {busy ? 'Đang tải…' : 'Xem'}
            </Button>
          </Stack>
        </Paper>
      )}

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {order && (
        <Stack spacing={3}>
          <OrderTicket order={order} showTimeline />
          <Paper variant="outlined" sx={{ p: 3 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>
              Lịch sử trạng thái
            </Typography>
            <StatusHistoryLog history={order.status_history} />
          </Paper>
        </Stack>
      )}
    </Box>
  )
}
