import { lazy, Suspense } from 'react'
import { BrowserRouter, Navigate, Outlet, Route, Routes } from 'react-router-dom'
import { Box, CircularProgress, ThemeProvider } from '@mui/material'
import theme from './theme'
import { AuthProvider, useAuth } from './auth/AuthContext'
import AppShell from './components/AppShell'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import MenuPage from './pages/MenuPage'
import MyOrdersPage from './pages/MyOrdersPage'
import LookupPage from './pages/LookupPage'
import OrderDetailPage from './pages/OrderDetailPage'

const DashboardPage = lazy(() => import('./pages/admin/DashboardPage'))
const AdminOrdersPage = lazy(() => import('./pages/admin/AdminOrdersPage'))
const MenuAdminPage = lazy(() => import('./pages/admin/MenuAdminPage'))
const ReportPage = lazy(() => import('./pages/admin/ReportPage'))
const SettingsPage = lazy(() => import('./pages/admin/SettingsPage'))
const LogsPage = lazy(() => import('./pages/admin/LogsPage'))

function Loader() {
  return (
    <Box sx={{ display: 'grid', placeItems: 'center', minHeight: '100vh' }}>
      <CircularProgress />
    </Box>
  )
}

function RequireAuth() {
  const { user, loading } = useAuth()
  if (loading) return <Loader />
  if (!user) return <Navigate to="/login" replace />
  return <Outlet />
}

function RequireAdmin() {
  const { user, loading } = useAuth()
  if (loading) return <Loader />
  if (!user) return <Navigate to="/login" replace />
  if (user.role !== 'admin') return <Navigate to="/admin/orders" replace />
  return <Outlet />
}

function RequireOps() {
  const { user, loading } = useAuth()
  if (loading) return <Loader />
  if (!user) return <Navigate to="/login" replace />
  if (user.role === 'customer') return <Navigate to="/menu" replace />
  return <Outlet />
}

export default function App() {
  const basename = import.meta.env.VITE_BASENAME ?? ''

  return (
    <ThemeProvider theme={theme}>
      <AuthProvider>
        <BrowserRouter basename={basename}>
          <Suspense fallback={<Loader />}>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />

              <Route element={<AppShell />}>
                <Route path="/menu" element={<MenuPage />} />
                <Route path="/lookup" element={<LookupPage />} />
                <Route path="/orders/:orderCode" element={<OrderDetailPage />} />

                <Route element={<RequireAuth />}>
                  <Route path="/orders" element={<MyOrdersPage />} />
                </Route>

                <Route element={<RequireOps />}>
                  <Route path="/admin/orders" element={<AdminOrdersPage />} />
                </Route>

                <Route element={<RequireAdmin />}>
                  <Route path="/admin" element={<DashboardPage />} />
                  <Route path="/admin/menu" element={<MenuAdminPage />} />
                  <Route path="/admin/report" element={<ReportPage />} />
                  <Route path="/admin/settings" element={<SettingsPage />} />
                  <Route path="/admin/logs" element={<LogsPage />} />
                </Route>
              </Route>

              <Route path="/" element={<Navigate to="/menu" replace />} />
              <Route path="*" element={<Navigate to="/menu" replace />} />
            </Routes>
          </Suspense>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  )
}
