import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// API calls use VITE_API_BASE in src/api/client.ts, so no dev proxy is needed
// (this also avoids collisions between frontend routes like /menu and backend API routes).
//
// `base` controls where built assets are referenced from. To serve the build
// under FastAPI at /app, build with:  VITE_BASENAME=/app npm run build
// (both the asset base and the React Router basename are derived from VITE_BASENAME).
const raw = process.env.VITE_BASENAME ?? ''
const base = raw ? (raw.endsWith('/') ? raw : `${raw}/`) : '/'

export default defineConfig({
  base,
  plugins: [react()],
  server: {
    port: 5173,
  },
})
