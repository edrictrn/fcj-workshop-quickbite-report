# QuickBite Frontend

React + TypeScript + Material UI frontend for QuickBite. This folder belongs to the unified QuickBite project and connects to the FastAPI backend through REST API.

## Local setup

Start backend first:

```bash
cd ../backend
python scripts/init_db_sqlite.py
uvicorn main:app --reload
```

Then start frontend:

```bash
cd ../frontend
npm install
cp .env.example .env.local
npm run dev
```

Open:

```text
http://localhost:5173
```

## Features

Customer:

```text
Register / login
Browse menu
Search, filter by category/price, sort by name/price
Create order
View order history
```

Admin:

```text
Dashboard metrics
Order board and status update
Menu management: create, edit, upload image, hide item
System settings and operation logs
Kitchen/delivery staff order board
Public order lookup by order_code
Business report: daily revenue, AOV, top items, status counts, CSV exports
```

## Deployment note

For AWS workshop deployment, recommended architecture:

```text
Frontend React -> S3 + CloudFront
Backend FastAPI -> EC2
Database -> RDS PostgreSQL
Images -> S3
Logs/metrics -> CloudWatch
```

Set `VITE_API_BASE` to the backend API URL before building:

```env
VITE_API_BASE=http://<EC2_PUBLIC_IP>:8000
```

If you build React and serve it through FastAPI under `/app`, set `VITE_BASENAME=/app`
when building. This drives both the React Router basename and the Vite asset base:

```bash
VITE_BASENAME=/app npm run build
```

Then copy/keep the build at `backend/../frontend/dist`. The backend serves it at `/app`
with a SPA fallback, so deep routes like `/app/admin/report` work on refresh.
For S3 + CloudFront at the root domain, build normally (`npm run build`) and configure
CloudFront to return `index.html` for 403/404 so client-side routes resolve.

## Known issues / technical debt

- `npm audit` reports 2 moderate advisories from `esbuild` (via Vite's dev server,
  GHSA-67mh-4wv8-2f99). This affects the local dev server only, not the production
  build. The fix bumps Vite to a new major (breaking), so it is deferred for now —
  do not run `npm audit fix --force` without testing the upgrade separately.
- The production bundle is code-split: admin pages (DataGrid + Charts) load on demand,
  so the initial bundle is small. No further action needed for the workshop.
