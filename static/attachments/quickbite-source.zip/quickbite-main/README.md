# QuickBite Unified Project

QuickBite is a food ordering platform built as one unified project with a FastAPI backend and a React TypeScript frontend. This version also reuses suitable ideas from the previous SE-main smart parking project: system configuration, mock payment, tracking code lookup, operation logs, CSV export reports, and expanded staff roles.

```text
QuickBite/
├── backend/
│   ├── main.py
│   ├── routers/
│   ├── models/
│   ├── schemas/
│   ├── sql/
│   ├── scripts/
│   └── requirements.txt
│
├── frontend/
│   ├── src/
│   ├── package.json
│   ├── vite.config.ts
│   └── .env.example
│
└── README.md
```

## Main features

Customer:

```text
Register / login
Browse, search, filter, and sort menu
Create order with COD or mock e-wallet payment
View order history
Public order lookup by order_code
```

Admin / operations:

```text
Admin dashboard
Order board
Kitchen staff / delivery staff role flow
Menu management
Business reports from SQL views
CSV export: orders, revenue, top items
System configuration: delivery fee, tax, open status, open hours, service area
Operation logs / audit trail
S3 image upload endpoint
Health check endpoint for monitoring
```

## Run locally

### 1. Backend

```bash
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python scripts/init_db_sqlite.py
uvicorn main:app --reload
```

Backend runs at:

```text
http://localhost:8000
http://localhost:8000/docs
```

### 2. Frontend

Open another terminal:

```bash
cd frontend
npm install
copy .env.example .env.local
npm run dev
```

Frontend runs at:

```text
http://localhost:5173
```

For macOS/Linux, replace `copy` with:

```bash
cp .env.example .env.local
```

## Demo accounts

```text
Admin:    admin@quickbite.com / Admin@123
Customer: customer@quickbite.com / Customer@123
Kitchen:  kitchen@quickbite.com / Customer@123
Delivery: delivery@quickbite.com / Customer@123
```

## AWS workshop architecture

Recommended deployment architecture:

```text
React Frontend        -> Amazon S3 + CloudFront
FastAPI Backend       -> Amazon EC2
PostgreSQL Database   -> Amazon RDS
Menu Images           -> Amazon S3
Logs/Metrics/Alerts   -> Amazon CloudWatch
```

This structure is suitable for the workshop because the system has a practical use case, end-to-end flow, SQL database scripts, admin dashboard, reporting, upload endpoint, role-based operations, audit logs, CSV exports, mock payment flow, and monitoring-ready health check.

## Docker Compose local demo

This project can be shared and run with Docker. Docker runs the whole local stack:

```text
React/Vite frontend -> FastAPI backend -> PostgreSQL database
                              |
                              -> Mailpit local SMTP inbox
```

Run from the `QuickBite/` root folder:

```bash
docker compose up --build
```

Open:

```text
Frontend:      http://localhost:5173
Backend docs:  http://localhost:8000/docs
Health check:  http://localhost:8000/health
Mailpit inbox: http://localhost:8025
```

Reset the demo database:

```bash
docker compose down -v
docker compose up --build
```

You do not need to commit or send `node_modules/`, `venv/`, `quickbite.db`, `dist/`, or `__pycache__/`. Docker rebuilds these generated files automatically.

## Local email simulation before Lambda + SES

QuickBite now supports local email simulation with Mailpit. This is useful before deploying AWS Lambda + SES.

When the Docker stack is running, Mailpit provides:

```text
SMTP host inside Docker: mailpit
SMTP port: 1025
Web inbox: http://localhost:8025
```

In Docker, the backend is configured with:

```env
EMAIL_ENABLED=true
EMAIL_BACKEND=smtp
EMAIL_FROM=no-reply@quickbite.local
SMTP_HOST=mailpit
SMTP_PORT=1025
```

Email events currently supported:

```text
Order created             -> confirmation email
Order status updated      -> status update email
POST /emails/test         -> manual test email
GET  /emails/config       -> safe email configuration view for admin
```

How to test:

```text
1. Run: docker compose up --build
2. Open frontend: http://localhost:5173
3. Login as customer and create an order
4. Open Mailpit: http://localhost:8025
5. Check the QuickBite confirmation email
```

This local flow is only for development/demo:

```text
Local Docker phase: FastAPI -> SMTP -> Mailpit
AWS phase:          FastAPI -> Lambda -> SES -> real email inbox
```

## Troubleshooting

### `localhost` does not load (Windows / Docker Desktop)

On some Windows + Docker Desktop setups `localhost` fails to reach the containers.
Use the loopback IP `127.0.0.1` instead:

```text
Frontend: http://127.0.0.1:5173
Backend:  http://127.0.0.1:8000/docs
Mailpit:  http://127.0.0.1:8025
```

The default CORS origins and `VITE_API_BASE` already include `127.0.0.1`, so both
addresses work out of the box.

### Quick health check

```bash
curl http://127.0.0.1:8000/health
curl http://127.0.0.1:8000/docs
```
