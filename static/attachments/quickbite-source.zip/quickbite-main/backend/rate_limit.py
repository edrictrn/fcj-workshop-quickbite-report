"""Shared rate limiter (slowapi) used to protect auth and public lookup endpoints."""

from slowapi import Limiter
from slowapi.util import get_remote_address

# Keyed by client IP. Endpoints opt in with @limiter.limit("N/minute").
limiter = Limiter(key_func=get_remote_address)
