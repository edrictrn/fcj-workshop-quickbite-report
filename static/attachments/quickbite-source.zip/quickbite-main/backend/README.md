# QuickBite Backend API

FastAPI backend for the QuickBite food ordering platform. This folder is part of the unified QuickBite monorepo.

## Local setup

```bash
cd backend
python -m venv venv
# Windows
venv\Scripts\activate
# macOS/Linux
# source venv/bin/activate

pip install -r requirements.txt
python scripts/init_db_sqlite.py
uvicorn main:app --reload
```

API docs:

```text
http://localhost:8000/docs
```

Health check:

```text
http://localhost:8000/health
```

Demo accounts:

```text
Admin:    admin@quickbite.com / Admin@123
Customer: customer@quickbite.com / Customer@123
Kitchen:  kitchen@quickbite.com / Customer@123
Delivery: delivery@quickbite.com / Customer@123
```

## Database

Local development uses SQLite generated from raw SQL files:

```text
sql/schema_sqlite.sql
sql/seed_sqlite.sql
sql/views_sqlite.sql
```

AWS deployment should use Amazon RDS PostgreSQL:

```bash
psql "postgresql://postgres:<password>@<rds-endpoint>:5432/quickbite" -f sql/schema_postgres.sql
psql "postgresql://postgres:<password>@<rds-endpoint>:5432/quickbite" -f sql/seed_postgres.sql
psql "postgresql://postgres:<password>@<rds-endpoint>:5432/quickbite" -f sql/views_postgres.sql
```

Then set `.env`:

```env
DATABASE_URL=postgresql://postgres:<password>@<rds-endpoint>:5432/quickbite
AUTO_CREATE_TABLES=false
SECRET_KEY=change-this-in-production
```

## Main API groups

```text
/auth       login, register, profile
/menu       menu browsing and admin menu CRUD
/orders     customer order flow, lookup, kitchen/delivery queues
/payments   COD/mock e-wallet payment lifecycle
/settings   public/admin system configuration
/reports    SQL-view based business reports and CSV exports
/logs       operation audit logs
/uploads    S3 image upload endpoint
/health     health check for monitoring
```

## Local E2E test

Run after installing dependencies:

```bash
python scripts/e2e_local.py
```

## Email demo with Mailpit

The backend can send local demo emails through SMTP. In Docker Compose, the SMTP server is Mailpit.

Important environment variables:

```env
EMAIL_ENABLED=true
EMAIL_BACKEND=smtp
EMAIL_FROM=no-reply@quickbite.local
SMTP_HOST=mailpit
SMTP_PORT=1025
EMAIL_FAIL_SILENTLY=true
```

Useful endpoints:

```text
GET  /emails/config   # admin only
POST /emails/test     # authenticated user
```

Order confirmation and status update emails are also sent automatically when `EMAIL_ENABLED=true`.
Open the local inbox at `http://localhost:8025`.

## Database migrations (Alembic)

The `sql/schema_*.sql` files contain `DROP TABLE ... CREATE TABLE` and are for
**local/demo reset only** — never run them against a production database.

For production (e.g. AWS RDS), use Alembic migrations instead:

```bash
# point Alembic at the target DB
export DATABASE_URL=postgresql://user:pass@<rds-endpoint>:5432/quickbite
alembic upgrade head          # create/upgrade schema
alembic revision --autogenerate -m "describe change"   # after editing models
```

Set `AUTO_CREATE_TABLES=false` in production so the app does not call
`create_all()` and Alembic remains the single source of truth for schema changes.
