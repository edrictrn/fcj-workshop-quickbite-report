from datetime import date, datetime, time as dtime, timezone
from decimal import Decimal, ROUND_HALF_UP
import secrets
from typing import List
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from rate_limit import limiter
from sqlalchemy import func
from sqlalchemy.orm import Session

from auth_utils import get_current_user, require_admin, require_order_operator, role_value
from database import get_db
from email_utils import send_order_confirmation_email, send_order_status_email
from log_utils import log_operation
from models import Item, Order, OrderItem, OrderStatus, OrderStatusHistory, Payment, PaymentMethod, PaymentStatus
from schemas import AdminOrderResponse, CreateOrderRequest, OrderResponse, UpdateOrderStatusRequest
from settings_utils import get_setting, get_setting_bool, get_setting_decimal

router = APIRouter()

VN_TZ = ZoneInfo("Asia/Ho_Chi_Minh")
CENT = Decimal("0.01")


def generate_order_code(order_id: int) -> str:
    return f"QB-{datetime.now(timezone.utc):%Y%m%d}-{order_id:04d}"


def generate_lookup_token() -> str:
    # Short, hard-to-guess token so the public tracking endpoint is not enumerable.
    return secrets.token_urlsafe(8)


def _q(value: Decimal) -> Decimal:
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def compute_breakdown(db: Session, subtotal: Decimal) -> dict:
    # Money is computed with Decimal to avoid binary float rounding errors.
    delivery_fee = get_setting_decimal(db, "delivery_fee", "0")
    tax_rate = get_setting_decimal(db, "tax_rate", "0")
    tax_amount = _q(subtotal * tax_rate)
    total = _q(subtotal + delivery_fee + tax_amount)
    return {
        "subtotal": _q(subtotal),
        "delivery_fee": _q(delivery_fee),
        "tax_amount": tax_amount,
        "total": total,
    }


def check_opening_hours(db: Session) -> None:
    """Optionally block orders outside the configured open/close window (VN time)."""
    if not get_setting_bool(db, "enforce_open_hours", False):
        return
    open_s = get_setting(db, "restaurant_open_time", "07:00")
    close_s = get_setting(db, "restaurant_close_time", "21:30")
    try:
        oh, om = (int(x) for x in open_s.split(":"))
        ch, cm = (int(x) for x in close_s.split(":"))
        open_t, close_t = dtime(oh, om), dtime(ch, cm)
    except (ValueError, AttributeError):
        return  # malformed config -> don't block
    now_t = datetime.now(VN_TZ).time()
    within = open_t <= now_t <= close_t if open_t <= close_t else (now_t >= open_t or now_t <= close_t)
    if not within:
        raise HTTPException(
            status_code=400,
            detail=f"Ngoài giờ mở cửa ({open_s}–{close_s} giờ Việt Nam). Vui lòng quay lại sau.",
        )


def ensure_order_allowed_for_role(user, new_status: OrderStatus) -> None:
    role = role_value(user)
    if role == "admin":
        return
    if role == "kitchen_staff" and new_status in {OrderStatus.confirmed, OrderStatus.preparing, OrderStatus.ready}:
        return
    if role == "delivery_staff" and new_status in {OrderStatus.ready, OrderStatus.completed, OrderStatus.cancelled}:
        return
    raise HTTPException(status_code=403, detail="Vai trò hiện tại không được đổi sang trạng thái này")


@router.post("/", response_model=OrderResponse, status_code=201)
def create_order(payload: CreateOrderRequest, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    if not get_setting_bool(db, "restaurant_open", True):
        raise HTTPException(status_code=400, detail="Nhà hàng hiện đang tạm ngưng nhận đơn")
    check_opening_hours(db)

    subtotal = Decimal("0")
    order_items = []

    for order_item in payload.items:
        item = db.query(Item).filter(Item.id == order_item.item_id).first()
        if not item:
            raise HTTPException(status_code=404, detail=f"Món {order_item.item_id} không tồn tại")
        if not item.is_available:
            raise HTTPException(status_code=400, detail=f"Món '{item.name}' hiện không có sẵn")

        line_total = Decimal(item.price) * order_item.quantity
        subtotal += line_total
        order_items.append(OrderItem(item_id=item.id, quantity=order_item.quantity, price=item.price))

    min_order_value = get_setting_decimal(db, "min_order_value", "0")
    if subtotal < min_order_value:
        raise HTTPException(status_code=400, detail=f"Giá trị món tối thiểu là {min_order_value:.0f} VND")

    breakdown = compute_breakdown(db, subtotal)
    method = PaymentMethod(payload.payment_method)
    payment_status = PaymentStatus.cod if method == PaymentMethod.cod else PaymentStatus.pending

    order = Order(
        user_id=current_user.id,
        subtotal=breakdown["subtotal"],
        delivery_fee=breakdown["delivery_fee"],
        tax_amount=breakdown["tax_amount"],
        total=breakdown["total"],
        note=payload.note,
        items=order_items,
    )
    db.add(order)
    db.flush()
    order.order_code = generate_order_code(order.id)
    order.lookup_token = generate_lookup_token()
    db.add(
        OrderStatusHistory(
            order_id=order.id,
            old_status=None,
            new_status=OrderStatus.pending.value,
            changed_by=current_user.id,
            note="Đơn được tạo",
        )
    )
    db.add(
        Payment(
            order_id=order.id,
            method=method,
            status=payment_status,
            amount=breakdown["total"],
            provider_transaction_id=None if method == PaymentMethod.cod else f"MOCK-{order.order_code}",
        )
    )
    log_operation(
        db,
        current_user,
        action="create_order",
        target_type="order",
        target_id=order.order_code,
        detail=f"items={len(order_items)}, subtotal={breakdown['subtotal']}, total={breakdown['total']}, payment={method.value}",
    )
    db.commit()
    db.refresh(order)

    # Local SMTP/Mailpit email simulation. Delivery failures are fail-silent by default
    # so the order creation flow still succeeds if the demo inbox is not running.
    email_result = send_order_confirmation_email(order)
    if email_result.get("status") in {"sent", "failed"}:
        log_operation(
            db,
            current_user,
            action="send_order_confirmation_email",
            target_type="order",
            target_id=order.order_code,
            detail=f"email_status={email_result.get('status')}, to={getattr(order.user, 'email', None)}",
        )
        db.commit()

    return order


@router.get("/my", response_model=List[OrderResponse])
def get_my_orders(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    return (
        db.query(Order)
        .filter(Order.user_id == current_user.id)
        .order_by(Order.created_at.desc(), Order.id.desc())
        .all()
    )


@router.get("/lookup/{order_code}", response_model=OrderResponse)
@limiter.limit("20/minute")
def lookup_order(
    request: Request,
    order_code: str,
    token: str = Query(..., min_length=4, description="Mã tra cứu (lookup_token) đi kèm đơn"),
    db: Session = Depends(get_db),
):
    """Public tracking endpoint. Requires both the order code and its lookup_token,
    so order codes alone cannot be enumerated to read other people's orders."""
    normalized = order_code.strip().upper()
    order = (
        db.query(Order)
        .filter(func.upper(Order.order_code) == normalized)
        .filter(Order.lookup_token == token)
        .first()
    )
    if not order:
        raise HTTPException(status_code=404, detail="Không tìm thấy đơn hàng theo mã tra cứu")
    return order


@router.get("/staff/queue", response_model=List[AdminOrderResponse])
def get_staff_queue(db: Session = Depends(get_db), operator=Depends(require_order_operator)):
    role = role_value(operator)
    query = db.query(Order)
    if role == "kitchen_staff":
        query = query.filter(Order.status.in_([OrderStatus.pending, OrderStatus.confirmed, OrderStatus.preparing]))
    elif role == "delivery_staff":
        query = query.filter(Order.status.in_([OrderStatus.ready, OrderStatus.completed]))
    return query.order_by(Order.created_at.asc(), Order.id.asc()).all()


@router.get("/admin/all", response_model=List[AdminOrderResponse])
def get_all_orders(db: Session = Depends(get_db), admin=Depends(require_admin)):
    return db.query(Order).order_by(Order.created_at.desc(), Order.id.desc()).all()


@router.get("/admin/dashboard")
def get_dashboard(db: Session = Depends(get_db), admin=Depends(require_admin)):
    total_orders = db.query(func.count(Order.id)).scalar() or 0
    total_revenue = (
        db.query(func.coalesce(func.sum(Order.total), 0))
        .filter(Order.status != OrderStatus.cancelled)
        .scalar()
        or 0
    )
    pending_orders = db.query(func.count(Order.id)).filter(Order.status == OrderStatus.pending).scalar() or 0
    today_revenue = (
        db.query(func.coalesce(func.sum(Order.total), 0))
        .filter(Order.status != OrderStatus.cancelled)
        .filter(func.date(Order.created_at) == date.today().isoformat())
        .scalar()
        or 0
    )

    status_rows = db.query(Order.status, func.count(Order.id)).group_by(Order.status).all()
    status_counts = {str(status.value if hasattr(status, "value") else status): count for status, count in status_rows}

    top_rows = (
        db.query(Item.name, func.sum(OrderItem.quantity).label("sold"), func.sum(OrderItem.quantity * OrderItem.price).label("revenue"))
        .join(OrderItem, OrderItem.item_id == Item.id)
        .join(Order, Order.id == OrderItem.order_id)
        .filter(Order.status != OrderStatus.cancelled)
        .group_by(Item.id, Item.name)
        .order_by(func.sum(OrderItem.quantity).desc())
        .limit(5)
        .all()
    )
    top_items = [{"name": name, "sold": int(sold or 0), "revenue": float(revenue or 0)} for name, sold, revenue in top_rows]

    payment_rows = db.query(Payment.status, func.count(Payment.id)).group_by(Payment.status).all()
    payment_counts = {str(status.value if hasattr(status, "value") else status): count for status, count in payment_rows}

    return {
        "total_orders": int(total_orders),
        "total_revenue": float(total_revenue),
        "today_revenue": float(today_revenue),
        "pending_orders": int(pending_orders),
        "status_counts": status_counts,
        "payment_counts": payment_counts,
        "top_items": top_items,
    }


@router.get("/{order_id}", response_model=OrderResponse)
def get_order(order_id: int, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Không tìm thấy đơn hàng")
    if order.user_id != current_user.id and role_value(current_user) not in {"admin", "kitchen_staff", "delivery_staff"}:
        raise HTTPException(status_code=403, detail="Không có quyền xem đơn này")
    return order


@router.patch("/{order_id}/status", response_model=OrderResponse)
def update_order_status(order_id: int, payload: UpdateOrderStatusRequest, db: Session = Depends(get_db), operator=Depends(require_order_operator)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Không tìm thấy đơn hàng")

    try:
        new_status = OrderStatus(payload.status)
    except ValueError:
        allowed = ", ".join([status.value for status in OrderStatus])
        raise HTTPException(status_code=400, detail=f"Status không hợp lệ. Allowed: {allowed}")

    ensure_order_allowed_for_role(operator, new_status)
    old_status = order.status.value if hasattr(order.status, "value") else str(order.status)
    order.status = new_status
    db.add(
        OrderStatusHistory(
            order_id=order.id,
            old_status=old_status,
            new_status=new_status.value,
            changed_by=getattr(operator, "id", None),
            note=payload.note if getattr(payload, "note", None) else "Cập nhật trạng thái",
        )
    )
    log_operation(
        db,
        operator,
        action="update_order_status",
        target_type="order",
        target_id=order.order_code or order.id,
        detail=f"{old_status} -> {new_status.value}",
    )

    db.commit()
    db.refresh(order)

    email_result = send_order_status_email(order, old_status=old_status)
    if email_result.get("status") in {"sent", "failed"}:
        log_operation(
            db,
            operator,
            action="send_order_status_email",
            target_type="order",
            target_id=order.order_code or order.id,
            detail=f"email_status={email_result.get('status')}, to={getattr(order.user, 'email', None)}",
        )
        db.commit()

    return order
