from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from auth_utils import get_current_user, require_order_operator, role_value
from database import get_db
from log_utils import log_operation
from models import Order, OrderStatus, Payment, PaymentMethod, PaymentStatus
from schemas import PaymentCompleteRequest, PaymentRequest, PaymentResponse

router = APIRouter()


def _can_access_order(user, order: Order) -> bool:
    return order.user_id == user.id or role_value(user) in {"admin", "kitchen_staff", "delivery_staff"}


@router.post("/initiate", response_model=PaymentResponse, status_code=201)
def initiate_payment(payload: PaymentRequest, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    order = db.query(Order).filter(Order.id == payload.order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Không tìm thấy đơn hàng")
    if not _can_access_order(current_user, order):
        raise HTTPException(status_code=403, detail="Không có quyền thanh toán đơn này")

    method = PaymentMethod(payload.method)
    status = PaymentStatus.cod if method == PaymentMethod.cod else PaymentStatus.pending
    provider_id = None if method == PaymentMethod.cod else f"MOCK-{order.order_code or order.id}"

    payment = order.payment
    if payment:
        payment.method = method
        payment.status = status
        payment.amount = order.total
        payment.provider_transaction_id = provider_id
    else:
        payment = Payment(
            order_id=order.id,
            method=method,
            status=status,
            amount=order.total,
            provider_transaction_id=provider_id,
        )
        db.add(payment)

    log_operation(
        db,
        current_user,
        action="initiate_payment",
        target_type="payment",
        target_id=order.order_code or order.id,
        detail=f"method={method.value}, amount={order.total}",
    )
    db.commit()
    db.refresh(payment)
    return payment


@router.get("/status/{payment_id}", response_model=PaymentResponse)
def payment_status(payment_id: int, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    payment = db.query(Payment).filter(Payment.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Không tìm thấy thanh toán")
    if not _can_access_order(current_user, payment.order):
        raise HTTPException(status_code=403, detail="Không có quyền xem thanh toán này")
    return payment


@router.post("/{payment_id}/mock-complete", response_model=PaymentResponse)
def mock_complete_payment(
    payment_id: int,
    payload: PaymentCompleteRequest,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    payment = db.query(Payment).filter(Payment.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Không tìm thấy thanh toán")
    if not _can_access_order(current_user, payment.order):
        raise HTTPException(status_code=403, detail="Không có quyền cập nhật thanh toán này")
    if payment.method != PaymentMethod.mock_ewallet:
        raise HTTPException(status_code=400, detail="Chỉ thanh toán mock_ewallet mới dùng được endpoint này")

    payment.status = PaymentStatus.paid if payload.success else PaymentStatus.failed
    payment.paid_at = datetime.utcnow() if payload.success else None
    if payload.success and payment.order.status == OrderStatus.pending:
        payment.order.status = OrderStatus.confirmed

    log_operation(
        db,
        current_user,
        action="mock_payment_complete",
        target_type="payment",
        target_id=payment.id,
        detail=f"status={payment.status.value}, order={payment.order.order_code}",
    )
    db.commit()
    db.refresh(payment)
    return payment


@router.post("/{payment_id}/cancel", response_model=PaymentResponse)
def cancel_payment(payment_id: int, db: Session = Depends(get_db), operator=Depends(require_order_operator)):
    payment = db.query(Payment).filter(Payment.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Không tìm thấy thanh toán")
    payment.status = PaymentStatus.cancelled
    log_operation(db, operator, action="cancel_payment", target_type="payment", target_id=payment.id)
    db.commit()
    db.refresh(payment)
    return payment
