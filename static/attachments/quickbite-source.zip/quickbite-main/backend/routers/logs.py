from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from auth_utils import require_admin
from database import get_db
from models import OperationLog
from schemas import OperationLogResponse

router = APIRouter()


@router.get("/admin", response_model=List[OperationLogResponse])
def get_operation_logs(limit: int = 100, db: Session = Depends(get_db), admin=Depends(require_admin)):
    limit = max(1, min(limit, 500))
    return db.query(OperationLog).order_by(OperationLog.created_at.desc(), OperationLog.id.desc()).limit(limit).all()
