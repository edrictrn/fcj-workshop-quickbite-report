from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from auth_utils import require_admin
from database import get_db
from log_utils import log_operation
from models import Category, Item
from schemas import CategoryResponse, CreateCategoryRequest, ItemRequest, ItemResponse, ItemUpdateRequest

router = APIRouter()


@router.get("/categories", response_model=List[CategoryResponse])
def get_categories(db: Session = Depends(get_db)):
    return db.query(Category).order_by(Category.name.asc()).all()


@router.post("/categories", response_model=CategoryResponse, status_code=201)
def create_category(payload: CreateCategoryRequest, db: Session = Depends(get_db), admin=Depends(require_admin)):
    existing = db.query(Category).filter(Category.name == payload.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="Danh mục đã tồn tại")
    category = Category(name=payload.name)
    db.add(category)
    db.flush()
    log_operation(db, admin, action="create_category", target_type="category", target_id=category.id, detail=category.name)
    db.commit()
    db.refresh(category)
    return category


def apply_menu_filters(
    query,
    category_id: Optional[int] = None,
    search: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
):
    if category_id:
        query = query.filter(Item.category_id == category_id)
    if search:
        keyword = search.strip()
        if keyword:
            query = query.filter(Item.name.ilike(f"%{keyword}%"))
    if min_price is not None:
        query = query.filter(Item.price >= min_price)
    if max_price is not None:
        query = query.filter(Item.price <= max_price)
    return query


def apply_menu_sort(query, sort_by: str = "name", sort_order: str = "asc"):
    sort_columns = {
        "id": Item.id,
        "name": Item.name,
        "price": Item.price,
    }
    column = sort_columns.get((sort_by or "name").lower(), Item.name)
    if (sort_order or "asc").lower() == "desc":
        return query.order_by(column.desc(), Item.id.asc())
    return query.order_by(column.asc(), Item.id.asc())


@router.get("/", response_model=List[ItemResponse])
def get_menu(
    category_id: Optional[int] = None,
    search: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    sort_by: str = "name",
    sort_order: str = "asc",
    db: Session = Depends(get_db),
):
    query = db.query(Item).filter(Item.is_available == True)
    query = apply_menu_filters(query, category_id, search, min_price, max_price)
    query = apply_menu_sort(query, sort_by, sort_order)
    return query.all()


@router.get("/admin/all", response_model=List[ItemResponse])
def get_all_items_for_admin(
    is_available: Optional[bool] = None,
    category_id: Optional[int] = None,
    search: Optional[str] = None,
    min_price: Optional[float] = None,
    max_price: Optional[float] = None,
    sort_by: str = "id",
    sort_order: str = "asc",
    db: Session = Depends(get_db),
    admin=Depends(require_admin),
):
    query = db.query(Item)
    if is_available is not None:
        query = query.filter(Item.is_available == is_available)
    query = apply_menu_filters(query, category_id, search, min_price, max_price)
    query = apply_menu_sort(query, sort_by, sort_order)
    return query.all()


@router.get("/{item_id}", response_model=ItemResponse)
def get_item(item_id: int, db: Session = Depends(get_db)):
    item = db.query(Item).filter(Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Không tìm thấy món ăn")
    return item


@router.post("/", response_model=ItemResponse, status_code=201)
def create_item(payload: ItemRequest, db: Session = Depends(get_db), admin=Depends(require_admin)):
    category = db.query(Category).filter(Category.id == payload.category_id).first()
    if not category:
        raise HTTPException(status_code=404, detail="Danh mục không tồn tại")

    existing = db.query(Item).filter(Item.name == payload.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="Tên món đã tồn tại")

    item = Item(
        name=payload.name,
        description=payload.description,
        price=payload.price,
        category_id=payload.category_id,
        is_available=payload.is_available,
        image_url=payload.image_url,
    )
    db.add(item)
    db.flush()
    log_operation(db, admin, action="create_item", target_type="item", target_id=item.id, detail=item.name)
    db.commit()
    db.refresh(item)
    return item


@router.patch("/{item_id}", response_model=ItemResponse)
def update_item(item_id: int, payload: ItemUpdateRequest, db: Session = Depends(get_db), admin=Depends(require_admin)):
    item = db.query(Item).filter(Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Không tìm thấy món ăn")

    update_data = payload.model_dump(exclude_unset=True)
    if "category_id" in update_data:
        category = db.query(Category).filter(Category.id == update_data["category_id"]).first()
        if not category:
            raise HTTPException(status_code=404, detail="Danh mục không tồn tại")

    if "name" in update_data:
        duplicate = db.query(Item).filter(Item.name == update_data["name"], Item.id != item_id).first()
        if duplicate:
            raise HTTPException(status_code=400, detail="Tên món đã tồn tại")

    for field, value in update_data.items():
        setattr(item, field, value)

    log_operation(db, admin, action="update_item", target_type="item", target_id=item.id, detail=", ".join(update_data.keys()))
    db.commit()
    db.refresh(item)
    return item


@router.delete("/{item_id}", status_code=204)
def delete_item(item_id: int, db: Session = Depends(get_db), admin=Depends(require_admin)):
    """Soft delete: hide the item instead of deleting rows referenced by old orders."""
    item = db.query(Item).filter(Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Không tìm thấy món ăn")
    item.is_available = False
    log_operation(db, admin, action="hide_item", target_type="item", target_id=item.id, detail=item.name)
    db.commit()
