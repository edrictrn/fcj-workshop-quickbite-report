"""S3 image upload for menu items.

Requires AWS credentials available to boto3 (IAM role on EC2, or env / ~/.aws).
Config via .env:
    AWS_REGION=ap-southeast-1
    S3_BUCKET_NAME=quickbite-menu-images

The returned URL assumes the object is publicly readable. On a modern bucket,
make objects readable via a bucket policy or serve them through CloudFront
(ACLs are disabled by default), rather than per-object public-read ACLs.
"""

import os
import uuid

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from auth_utils import require_admin
from database import get_db
from log_utils import log_operation

router = APIRouter()

AWS_REGION = os.getenv("AWS_REGION", "ap-southeast-1")
S3_BUCKET = os.getenv("S3_BUCKET_NAME")
# Optional public base URL for serving images (e.g. a CloudFront domain in front of a
# PRIVATE bucket). When set, uploaded image URLs use this base instead of the direct
# S3 URL — the secure, production-friendly option. Example:
#   MENU_IMAGE_BASE_URL=https://dxxxx.cloudfront.net
MENU_IMAGE_BASE_URL = os.getenv("MENU_IMAGE_BASE_URL")

ALLOWED_TYPES = {"image/jpeg": "jpg", "image/png": "png", "image/webp": "webp"}
MAX_BYTES = 5 * 1024 * 1024  # 5 MB


@router.post("/image")
async def upload_image(file: UploadFile = File(...), db: Session = Depends(get_db), admin=Depends(require_admin)):
    if not S3_BUCKET:
        raise HTTPException(
            status_code=503,
            detail="S3 chưa được cấu hình. Đặt S3_BUCKET_NAME trong .env.",
        )

    ext = ALLOWED_TYPES.get(file.content_type or "")
    if not ext:
        raise HTTPException(status_code=400, detail="Chỉ chấp nhận ảnh JPEG, PNG hoặc WebP.")

    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=400, detail="Ảnh vượt quá giới hạn 5MB.")

    # Imported lazily so the app still starts without boto3/AWS configured locally.
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError

    key = f"menu/{uuid.uuid4().hex}.{ext}"
    try:
        s3 = boto3.client("s3", region_name=AWS_REGION)
        s3.put_object(Bucket=S3_BUCKET, Key=key, Body=data, ContentType=file.content_type)
    except (BotoCoreError, ClientError) as exc:
        raise HTTPException(status_code=502, detail=f"Upload S3 thất bại: {exc}")

    if MENU_IMAGE_BASE_URL:
        # Served through CloudFront (bucket can stay private).
        url = f"{MENU_IMAGE_BASE_URL.rstrip('/')}/{key}"
    else:
        # Direct S3 URL — requires the object/prefix to be publicly readable.
        url = f"https://{S3_BUCKET}.s3.{AWS_REGION}.amazonaws.com/{key}"
    log_operation(db, admin, action="upload_image", target_type="s3_object", target_id=key, detail=file.filename)
    db.commit()
    return {"url": url, "key": key}
