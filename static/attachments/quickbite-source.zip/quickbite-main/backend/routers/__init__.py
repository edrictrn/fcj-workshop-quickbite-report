"""API routers exported with clear names for main.py."""

from .auth import router as auth_router
from .emails import router as emails_router
from .logs import router as logs_router
from .menu import router as menu_router
from .orders import router as orders_router
from .payments import router as payments_router
from .reports import router as reports_router
from .settings import router as settings_router
from .uploads import router as uploads_router

__all__ = [
    "auth_router",
    "emails_router",
    "logs_router",
    "menu_router",
    "orders_router",
    "payments_router",
    "reports_router",
    "settings_router",
    "uploads_router",
]
