from pydantic import BaseModel, EmailStr, Field
from fastapi import APIRouter, Depends

from auth_utils import get_current_user, require_admin
from email_utils import get_safe_email_config, send_email
from log_utils import log_operation
from database import get_db
from sqlalchemy.orm import Session

router = APIRouter()


class TestEmailRequest(BaseModel):
    to_email: EmailStr | None = None
    subject: str = Field(default="[QuickBite] Test email from local SMTP demo", max_length=120)
    message: str = Field(
        default="Đây là email test được gửi từ QuickBite qua Mailpit trước khi tích hợp AWS Lambda + SES.",
        max_length=1000,
    )


@router.get("/config")
def email_config(admin=Depends(require_admin)):
    """Return safe email configuration for demo/debugging."""
    return get_safe_email_config()


@router.post("/test")
def send_test_email(
    payload: TestEmailRequest,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Send a test email to Mailpit/SMTP.

    If `to_email` is omitted, the current user's email address is used.
    """
    recipient = payload.to_email or current_user.email
    result = send_email(
        str(recipient),
        payload.subject,
        payload.message,
        f"<p>{payload.message}</p><p><em>QuickBite local SMTP demo via Mailpit.</em></p>",
    )
    log_operation(
        db,
        current_user,
        action="send_test_email",
        target_type="email",
        target_id=str(recipient),
        detail=f"status={result.get('status')}",
    )
    db.commit()
    return result
