from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from auth_utils import require_admin
from database import get_db
from log_utils import log_operation
from models import SystemConfig
from schemas import SystemConfigResponse, UpdateConfigRequest
from settings_utils import ensure_default_settings

router = APIRouter()


@router.get("/public", response_model=List[SystemConfigResponse])
def public_settings(db: Session = Depends(get_db)):
    ensure_default_settings(db)
    db.commit()
    keys = [
        "delivery_fee",
        "tax_rate",
        "min_order_value",
        "restaurant_open",
        "enforce_open_hours",
        "restaurant_open_time",
        "restaurant_close_time",
        "service_area",
    ]
    return db.query(SystemConfig).filter(SystemConfig.key.in_(keys)).order_by(SystemConfig.key.asc()).all()


@router.get("/admin", response_model=List[SystemConfigResponse])
def admin_settings(db: Session = Depends(get_db), admin=Depends(require_admin)):
    ensure_default_settings(db)
    db.commit()
    return db.query(SystemConfig).order_by(SystemConfig.key.asc()).all()


@router.patch("/admin/{key}", response_model=SystemConfigResponse)
def update_setting(key: str, payload: UpdateConfigRequest, db: Session = Depends(get_db), admin=Depends(require_admin)):
    ensure_default_settings(db)
    config = db.query(SystemConfig).filter(SystemConfig.key == key).first()
    if not config:
        raise HTTPException(status_code=404, detail="Không tìm thấy cấu hình")

    old_value = config.value
    config.value = payload.value
    if payload.description is not None:
        config.description = payload.description
    log_operation(
        db,
        admin,
        action="update_setting",
        target_type="system_config",
        target_id=key,
        detail=f"{key}: {old_value} -> {config.value}",
    )
    db.commit()
    db.refresh(config)
    return config
