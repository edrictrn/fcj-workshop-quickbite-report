"""Reporting endpoints that read from database VIEWs.

Views:
    v_daily_revenue, v_item_sales, v_order_status_counts
"""

import csv
from io import StringIO

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import text
from sqlalchemy.orm import Session

from auth_utils import require_admin
from database import get_db

router = APIRouter()


@router.get("/daily-revenue")
def daily_revenue(days: int = 14, db: Session = Depends(get_db), admin=Depends(require_admin)):
    rows = db.execute(
        text(
            "SELECT day, order_count, revenue "
            "FROM v_daily_revenue ORDER BY day DESC LIMIT :n"
        ),
        {"n": days},
    ).fetchall()
    return [
        {"day": str(r[0]), "order_count": int(r[1]), "revenue": float(r[2])}
        for r in reversed(rows)
    ]


@router.get("/top-items")
def top_items(limit: int = 10, db: Session = Depends(get_db), admin=Depends(require_admin)):
    rows = db.execute(
        text(
            "SELECT item_name, total_sold, total_revenue "
            "FROM v_item_sales WHERE total_sold > 0 "
            "ORDER BY total_sold DESC LIMIT :n"
        ),
        {"n": limit},
    ).fetchall()
    return [
        {"name": r[0], "sold": int(r[1]), "revenue": float(r[2])}
        for r in rows
    ]


@router.get("/status-counts")
def status_counts(db: Session = Depends(get_db), admin=Depends(require_admin)):
    rows = db.execute(
        text("SELECT status, order_count FROM v_order_status_counts")
    ).fetchall()
    return {r[0]: int(r[1]) for r in rows}


def _csv_response(filename: str, headers: list[str], rows: list[tuple]):
    buffer = StringIO()
    writer = csv.writer(buffer)
    writer.writerow(headers)
    writer.writerows(rows)
    buffer.seek(0)
    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/export")
def export_report(type: str = "orders", db: Session = Depends(get_db), admin=Depends(require_admin)):
    """Export management reports as CSV, inspired by SE-main's admin report export."""
    report_type = type.strip().lower()

    if report_type == "orders":
        rows = db.execute(
            text(
                "SELECT o.order_code, u.name, u.email, o.status, o.total, "
                "COALESCE(p.method, ''), COALESCE(p.status, ''), o.created_at "
                "FROM orders o "
                "JOIN users u ON u.id = o.user_id "
                "LEFT JOIN payments p ON p.order_id = o.id "
                "ORDER BY o.created_at DESC"
            )
        ).fetchall()
        return _csv_response(
            "quickbite_orders.csv",
            ["order_code", "customer_name", "customer_email", "status", "total", "payment_method", "payment_status", "created_at"],
            rows,
        )

    if report_type == "revenue":
        rows = db.execute(text("SELECT day, order_count, revenue FROM v_daily_revenue ORDER BY day DESC")).fetchall()
        return _csv_response("quickbite_revenue.csv", ["day", "order_count", "revenue"], rows)

    if report_type == "items":
        rows = db.execute(
            text("SELECT item_name, total_sold, total_revenue FROM v_item_sales ORDER BY total_sold DESC")
        ).fetchall()
        return _csv_response("quickbite_items.csv", ["item_name", "total_sold", "total_revenue"], rows)

    raise HTTPException(status_code=400, detail="type phải là orders, revenue hoặc items")
