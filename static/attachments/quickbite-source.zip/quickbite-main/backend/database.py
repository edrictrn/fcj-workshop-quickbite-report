from dotenv import load_dotenv
load_dotenv()

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

# Local default uses SQLite so the project can run immediately without PostgreSQL.
# Run `python scripts/init_db_sqlite.py` to create quickbite.db from SQL scripts.
# When deploying to AWS RDS, set DATABASE_URL in .env, for example:
# postgresql://postgres:password@<rds-endpoint>:5432/quickbite
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./quickbite.db")
AUTO_CREATE_TABLES = os.getenv("AUTO_CREATE_TABLES", "false").lower() == "true"

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
