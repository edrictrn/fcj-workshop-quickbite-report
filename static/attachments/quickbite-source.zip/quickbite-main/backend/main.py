from pathlib import Path

import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from slowapi.errors import RateLimitExceeded
from slowapi import _rate_limit_exceeded_handler

from database import AUTO_CREATE_TABLES, Base, engine
from rate_limit import limiter
import models  # noqa: F401 - ensure models are imported before create_all
from routers import auth_router, emails_router, logs_router, menu_router, orders_router, payments_router, reports_router, settings_router, uploads_router

if AUTO_CREATE_TABLES:
    Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="QuickBite API",
    description="Food Ordering Platform API for local demo and AWS deployment",
    version="1.4.0",
)

# Rate limiting (slowapi): protects /auth/login, /auth/register and public order lookup
# against brute-force / enumeration. Returns HTTP 429 when the limit is exceeded.
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Restrict CORS to known frontend origins. A wildcard "*" combined with
# allow_credentials=True is rejected by browsers and is unsafe in production.
# Override CORS_ALLOW_ORIGINS in .env with your CloudFront/S3 domain on AWS.
ALLOWED_ORIGINS = [
    origin.strip()
    for origin in os.getenv(
        "CORS_ALLOW_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"
    ).split(",")
    if origin.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router, prefix="/auth", tags=["Auth"])
app.include_router(emails_router, prefix="/emails", tags=["Email Demo"])
app.include_router(menu_router, prefix="/menu", tags=["Menu"])
app.include_router(orders_router, prefix="/orders", tags=["Orders"])
app.include_router(payments_router, prefix="/payments", tags=["Payments"])
app.include_router(settings_router, prefix="/settings", tags=["Settings"])
app.include_router(reports_router, prefix="/reports", tags=["Reports"])
app.include_router(logs_router, prefix="/logs", tags=["Operation Logs"])
app.include_router(uploads_router, prefix="/uploads", tags=["Uploads"])

# Optional: after building React (`npm run build`), the dist lands at ../frontend/dist
# and FastAPI can serve it under /app for a single-server local demo.
# To build for this path: VITE_BASENAME=/app npm run build
PROJECT_ROOT = Path(__file__).resolve().parents[1]
react_dist_dir = (PROJECT_ROOT / "frontend" / "dist").resolve()
if react_dist_dir.exists():
    assets_dir = react_dist_dir / "assets"
    if assets_dir.exists():
        app.mount("/app/assets", StaticFiles(directory=str(assets_dir)), name="frontend-assets")

    @app.get("/app")
    @app.get("/app/{full_path:path}")
    def serve_spa(full_path: str = ""):
        # SPA fallback: serve the real file if it exists, otherwise return index.html
        # so deep client routes (e.g. /app/admin/report) work on refresh.
        candidate = (react_dist_dir / full_path).resolve()
        if full_path and react_dist_dir in candidate.parents and candidate.is_file():
            return FileResponse(str(candidate))
        return FileResponse(str(react_dist_dir / "index.html"))


@app.get("/")
def root():
    payload = {
        "message": "QuickBite API is running 🍔",
        "docs": "/docs",
        "frontend_dev": "http://localhost:5173",
        "frontend_static_if_built": "/app",
    }
    # Only reveal demo credentials on local/dev; keep them out of production responses.
    if os.getenv("SHOW_DEMO_ACCOUNTS", "true").strip().lower() in {"1", "true", "yes", "on"}:
        payload["demo_accounts"] = {
            "admin": "admin@quickbite.com / Admin@123",
            "customer": "customer@quickbite.com / Customer@123",
        }
    return payload


@app.get("/health")
def health_check():
    return {"status": "ok", "service": "quickbite-api", "version": "1.4.0"}
