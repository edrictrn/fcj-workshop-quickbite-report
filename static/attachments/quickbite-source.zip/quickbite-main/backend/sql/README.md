# QuickBite SQL files

This folder contains SQL scripts for creating and seeding the QuickBite database. The seed data includes:

```text
9 users: admin, customer, 5 extra customers, kitchen staff, delivery staff
8 categories
35 menu items
10 sample orders with order_code
10 sample payments
7 system configuration rows
3 sample operation logs
```

## Local SQLite

Use this for local demo without installing PostgreSQL:

```bash
python scripts/init_db_sqlite.py
uvicorn main:app --reload
```

Generated database:

```text
quickbite.db
```

## AWS RDS PostgreSQL

Use these files when deploying to Amazon RDS PostgreSQL:

```bash
psql "postgresql://postgres:password@<rds-endpoint>:5432/quickbite" -f sql/schema_postgres.sql
psql "postgresql://postgres:password@<rds-endpoint>:5432/quickbite" -f sql/seed_postgres.sql
psql "postgresql://postgres:password@<rds-endpoint>:5432/quickbite" -f sql/views_postgres.sql
```

Then set your `.env`:

```env
DATABASE_URL=postgresql://postgres:password@<rds-endpoint>:5432/quickbite
AUTO_CREATE_TABLES=false
```

Demo accounts:

```text
Admin:    admin@quickbite.com / Admin@123
Customer: customer@quickbite.com / Customer@123
Kitchen:  kitchen@quickbite.com / Customer@123
Delivery: delivery@quickbite.com / Customer@123
```
