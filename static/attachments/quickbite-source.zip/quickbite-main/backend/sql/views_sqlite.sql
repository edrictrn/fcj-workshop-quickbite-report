-- QuickBite reporting VIEWs (SQLite).
-- Run after schema + seed:  python scripts/init_db_sqlite.py
-- These move reporting logic into the database layer so the API only reads from views.
-- Cancelled orders are excluded from revenue (they were never fulfilled).

DROP VIEW IF EXISTS v_daily_revenue;
DROP VIEW IF EXISTS v_item_sales;
DROP VIEW IF EXISTS v_order_status_counts;

-- Doanh thu và số đơn theo ngày (bỏ đơn cancelled)
CREATE VIEW v_daily_revenue AS
SELECT date(created_at)        AS day,
       COUNT(*)                AS order_count,
       COALESCE(SUM(total), 0) AS revenue
FROM orders
WHERE status <> 'cancelled'
GROUP BY date(created_at);

-- Số lượng bán và doanh thu theo từng món (giữ cả món chưa bán: total_sold = 0;
-- bỏ phần thuộc đơn cancelled bằng CASE để không loại nhầm món chưa bán)
CREATE VIEW v_item_sales AS
SELECT i.id   AS item_id,
       i.name AS item_name,
       COALESCE(SUM(CASE WHEN o.status <> 'cancelled' THEN oi.quantity END), 0)              AS total_sold,
       COALESCE(SUM(CASE WHEN o.status <> 'cancelled' THEN oi.quantity * oi.price END), 0)    AS total_revenue
FROM items i
LEFT JOIN order_items oi ON oi.item_id = i.id
LEFT JOIN orders o       ON o.id = oi.order_id
GROUP BY i.id, i.name;

-- Đếm đơn theo trạng thái (giữ tất cả trạng thái, kể cả cancelled)
CREATE VIEW v_order_status_counts AS
SELECT status, COUNT(*) AS order_count
FROM orders
GROUP BY status;
