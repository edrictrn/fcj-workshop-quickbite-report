"""Wait until PostgreSQL is ready before starting FastAPI in Docker."""

from __future__ import annotations

import os
import sys
import time
from urllib.parse import urlparse

import psycopg2


def wait_for_postgres(database_url: str, timeout_seconds: int = 60) -> None:
    parsed = urlparse(database_url)
    deadline = time.time() + timeout_seconds
    last_error: Exception | None = None

    while time.time() < deadline:
        try:
            conn = psycopg2.connect(
                dbname=(parsed.path or "/quickbite").lstrip("/"),
                user=parsed.username,
                password=parsed.password,
                host=parsed.hostname,
                port=parsed.port or 5432,
                connect_timeout=3,
            )
            conn.close()
            print("PostgreSQL is ready.")
            return
        except Exception as exc:  # noqa: BLE001 - startup helper
            last_error = exc
            print(f"Waiting for PostgreSQL... {exc}")
            time.sleep(2)

    raise RuntimeError(f"PostgreSQL was not ready after {timeout_seconds}s: {last_error}")


if __name__ == "__main__":
    url = os.getenv("DATABASE_URL", "")
    if url.startswith("postgresql"):
        wait_for_postgres(url)
    else:
        print("DATABASE_URL is not PostgreSQL. Skipping DB wait.")
    sys.exit(0)
