"""Seed local QuickBite demo data.

Run:
    python scripts/seed_data.py

Demo accounts:
    admin@quickbite.com / Admin@123
    customer@quickbite.com / Customer@123

This ORM seeder mirrors the SQL seed files and creates:
    - 8 categories
    - 35 menu items
    - 10 sample orders
"""

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from auth_utils import hash_password  # noqa: E402
from database import Base, SessionLocal, engine  # noqa: E402
from models import Category, Item, Order, OrderItem, OrderStatus, Payment, PaymentMethod, PaymentStatus, User, UserRole  # noqa: E402
from settings_utils import ensure_default_settings  # noqa: E402


CATEGORIES = ['Rice', 'Noodles', 'Drinks', 'Snacks', 'Breakfast', 'Vegetarian', 'Desserts', 'Combos']

ITEMS = [{'name': 'Chicken Rice', 'description': 'Cơm gà văn phòng, nhiều rau, phù hợp bữa trưa.', 'price': 45000, 'category': 'Rice', 'image_url': 'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=800', 'is_available': True}, {'name': 'Beef Noodles', 'description': 'Mì bò nóng, có thể dùng nhanh trong giờ nghỉ.', 'price': 55000, 'category': 'Noodles', 'image_url': 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800', 'is_available': True}, {'name': 'Fried Rice', 'description': 'Cơm chiên trứng và rau củ, no lâu, giá tốt.', 'price': 42000, 'category': 'Rice', 'image_url': 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800', 'is_available': True}, {'name': 'Milk Tea', 'description': 'Trà sữa size M, ít đường, dùng kèm topping.', 'price': 30000, 'category': 'Drinks', 'image_url': 'https://images.unsplash.com/photo-1558857563-b371033873b8?w=800', 'is_available': True}, {'name': 'Spring Rolls', 'description': 'Chả giò giòn, phù hợp ăn nhẹ hoặc thêm vào combo.', 'price': 35000, 'category': 'Snacks', 'image_url': 'https://images.unsplash.com/photo-1544025162-d76694265947?w=800', 'is_available': True}, {'name': 'Grilled Pork Rice', 'description': 'Cơm sườn nướng dùng kèm đồ chua và nước mắm nhẹ.', 'price': 52000, 'category': 'Rice', 'image_url': 'https://placehold.co/800x600?text=Grilled+Pork+Rice', 'is_available': True}, {'name': 'Lemongrass Chicken Rice', 'description': 'Cơm gà sả ớt thơm nhẹ, phù hợp bữa trưa văn phòng.', 'price': 48000, 'category': 'Rice', 'image_url': 'https://placehold.co/800x600?text=Lemongrass+Chicken+Rice', 'is_available': True}, {'name': 'Teriyaki Chicken Bowl', 'description': 'Cơm gà sốt teriyaki, vị ngọt mặn cân bằng.', 'price': 59000, 'category': 'Rice', 'image_url': 'https://placehold.co/800x600?text=Teriyaki+Chicken+Bowl', 'is_available': True}, {'name': 'Salmon Rice Bowl', 'description': 'Cơm cá hồi áp chảo, ăn kèm rau củ và sốt mè.', 'price': 79000, 'category': 'Rice', 'image_url': 'https://placehold.co/800x600?text=Salmon+Rice+Bowl', 'is_available': True}, {'name': 'Braised Pork Rice', 'description': 'Cơm thịt kho trứng kiểu Việt, vị đậm đà, no lâu.', 'price': 50000, 'category': 'Rice', 'image_url': 'https://placehold.co/800x600?text=Braised+Pork+Rice', 'is_available': True}, {'name': 'Chicken Pho', 'description': 'Phở gà nước dùng thanh, phù hợp bữa sáng hoặc trưa.', 'price': 50000, 'category': 'Noodles', 'image_url': 'https://placehold.co/800x600?text=Chicken+Pho', 'is_available': True}, {'name': 'Seafood Udon', 'description': 'Mì udon hải sản nóng, có tôm, mực và rau xanh.', 'price': 68000, 'category': 'Noodles', 'image_url': 'https://placehold.co/800x600?text=Seafood+Udon', 'is_available': True}, {'name': 'Spicy Ramen', 'description': 'Ramen cay cấp độ vừa, có trứng và thịt lát.', 'price': 62000, 'category': 'Noodles', 'image_url': 'https://placehold.co/800x600?text=Spicy+Ramen', 'is_available': True}, {'name': 'Wonton Noodles', 'description': 'Mì hoành thánh nước dùng nhẹ, dễ ăn trong giờ nghỉ.', 'price': 54000, 'category': 'Noodles', 'image_url': 'https://placehold.co/800x600?text=Wonton+Noodles', 'is_available': True}, {'name': 'Vegetarian Vermicelli', 'description': 'Bún chay với rau củ, đậu hũ và nước sốt nhẹ.', 'price': 43000, 'category': 'Noodles', 'image_url': 'https://placehold.co/800x600?text=Vegetarian+Vermicelli', 'is_available': True}, {'name': 'Lemon Tea', 'description': 'Trà chanh mát, ít ngọt, phù hợp uống kèm món chính.', 'price': 22000, 'category': 'Drinks', 'image_url': 'https://placehold.co/800x600?text=Lemon+Tea', 'is_available': True}, {'name': 'Vietnamese Coffee', 'description': 'Cà phê sữa đá đậm vị, dùng cho buổi sáng hoặc xế chiều.', 'price': 25000, 'category': 'Drinks', 'image_url': 'https://placehold.co/800x600?text=Vietnamese+Coffee', 'is_available': True}, {'name': 'Iced Peach Tea', 'description': 'Trà đào lạnh, vị trái cây nhẹ và dễ uống.', 'price': 28000, 'category': 'Drinks', 'image_url': 'https://placehold.co/800x600?text=Iced+Peach+Tea', 'is_available': True}, {'name': 'Fresh Orange Juice', 'description': 'Nước cam tươi, bổ sung vitamin cho bữa ăn nhanh.', 'price': 32000, 'category': 'Drinks', 'image_url': 'https://placehold.co/800x600?text=Fresh+Orange+Juice', 'is_available': True}, {'name': 'Bottled Water', 'description': 'Nước suối đóng chai dùng kèm mọi combo.', 'price': 12000, 'category': 'Drinks', 'image_url': 'https://placehold.co/800x600?text=Bottled+Water', 'is_available': True}, {'name': 'French Fries', 'description': 'Khoai tây chiên giòn, phù hợp ăn nhẹ hoặc gọi thêm.', 'price': 30000, 'category': 'Snacks', 'image_url': 'https://placehold.co/800x600?text=French+Fries', 'is_available': True}, {'name': 'Fried Chicken Wings', 'description': 'Cánh gà chiên giòn, sốt nhẹ, phù hợp nhóm bạn.', 'price': 45000, 'category': 'Snacks', 'image_url': 'https://placehold.co/800x600?text=Fried+Chicken+Wings', 'is_available': True}, {'name': 'Cheese Sticks', 'description': 'Phô mai que kéo sợi, ăn nhanh trong giờ nghỉ.', 'price': 38000, 'category': 'Snacks', 'image_url': 'https://placehold.co/800x600?text=Cheese+Sticks', 'is_available': True}, {'name': 'Dumplings', 'description': 'Há cảo hấp mềm, dùng kèm nước tương gừng.', 'price': 40000, 'category': 'Snacks', 'image_url': 'https://placehold.co/800x600?text=Dumplings', 'is_available': True}, {'name': 'Garlic Bread', 'description': 'Bánh mì bơ tỏi giòn nhẹ, phù hợp ăn kèm soup hoặc mì.', 'price': 28000, 'category': 'Snacks', 'image_url': 'https://placehold.co/800x600?text=Garlic+Bread', 'is_available': True}, {'name': 'Banh Mi Omelette', 'description': 'Bánh mì trứng ốp la, nhanh gọn cho bữa sáng.', 'price': 35000, 'category': 'Breakfast', 'image_url': 'https://placehold.co/800x600?text=Banh+Mi+Omelette', 'is_available': True}, {'name': 'Breakfast Sandwich', 'description': 'Sandwich trứng, phô mai và rau, phù hợp mang đi.', 'price': 42000, 'category': 'Breakfast', 'image_url': 'https://placehold.co/800x600?text=Breakfast+Sandwich', 'is_available': True}, {'name': 'Sticky Rice Chicken', 'description': 'Xôi gà xé, hành phi và nước sốt nhẹ.', 'price': 38000, 'category': 'Breakfast', 'image_url': 'https://placehold.co/800x600?text=Sticky+Rice+Chicken', 'is_available': True}, {'name': 'Tofu Rice Bowl', 'description': 'Cơm đậu hũ sốt nấm, lựa chọn chay nhiều năng lượng.', 'price': 46000, 'category': 'Vegetarian', 'image_url': 'https://placehold.co/800x600?text=Tofu+Rice+Bowl', 'is_available': True}, {'name': 'Mushroom Fried Noodles', 'description': 'Mì xào nấm và rau củ, vị nhẹ, không quá dầu.', 'price': 47000, 'category': 'Vegetarian', 'image_url': 'https://placehold.co/800x600?text=Mushroom+Fried+Noodles', 'is_available': True}, {'name': 'Vegetable Salad', 'description': 'Salad rau củ tươi, sốt mè rang, phù hợp bữa ăn nhẹ.', 'price': 39000, 'category': 'Vegetarian', 'image_url': 'https://placehold.co/800x600?text=Vegetable+Salad', 'is_available': True}, {'name': 'Matcha Pudding', 'description': 'Pudding matcha mềm, vị ngọt vừa, dùng sau bữa ăn.', 'price': 29000, 'category': 'Desserts', 'image_url': 'https://placehold.co/800x600?text=Matcha+Pudding', 'is_available': True}, {'name': 'Chocolate Brownie', 'description': 'Brownie chocolate đậm vị, phần nhỏ cho món tráng miệng.', 'price': 35000, 'category': 'Desserts', 'image_url': 'https://placehold.co/800x600?text=Chocolate+Brownie', 'is_available': True}, {'name': 'Lunch Combo A', 'description': 'Combo cơm gà, nước uống và món ăn nhẹ cho bữa trưa.', 'price': 79000, 'category': 'Combos', 'image_url': 'https://placehold.co/800x600?text=Lunch+Combo+A', 'is_available': True}, {'name': 'Student Combo', 'description': 'Combo tiết kiệm gồm món chính và nước uống cho sinh viên.', 'price': 69000, 'category': 'Combos', 'image_url': 'https://placehold.co/800x600?text=Student+Combo', 'is_available': True}]

EXTRA_CUSTOMERS = [{'name': 'Minh Anh', 'email': 'minhanh@quickbite.com', 'password': 'Customer@123', 'role': 'customer'}, {'name': 'Hoang Nam', 'email': 'hoangnam@quickbite.com', 'password': 'Customer@123', 'role': 'customer'}, {'name': 'Linh Chi', 'email': 'linhchi@quickbite.com', 'password': 'Customer@123', 'role': 'customer'}, {'name': 'Tuan Kiet', 'email': 'tuankiet@quickbite.com', 'password': 'Customer@123', 'role': 'customer'}, {'name': 'Bao Tran', 'email': 'baotran@quickbite.com', 'password': 'Customer@123', 'role': 'customer'}]

STAFF_USERS = [{'name': 'Kitchen Staff', 'email': 'kitchen@quickbite.com', 'password': 'Customer@123', 'role': 'kitchen_staff'}, {'name': 'Delivery Staff', 'email': 'delivery@quickbite.com', 'password': 'Customer@123', 'role': 'delivery_staff'}]

SAMPLE_ORDERS = [{'user_id': 2, 'status': 'confirmed', 'note': 'Demo seeded order', 'items': [{'item_id': 1, 'quantity': 2}, {'item_id': 4, 'quantity': 1}]}, {'user_id': 2, 'status': 'pending', 'note': 'Customer wants less ice for drink', 'items': [{'item_id': 34, 'quantity': 1}, {'item_id': 20, 'quantity': 1}]}, {'user_id': 3, 'status': 'confirmed', 'note': 'Deliver to study room A1', 'items': [{'item_id': 7, 'quantity': 1}, {'item_id': 18, 'quantity': 2}]}, {'user_id': 4, 'status': 'preparing', 'note': 'Extra napkins please', 'items': [{'item_id': 13, 'quantity': 1}, {'item_id': 23, 'quantity': 1}]}, {'user_id': 5, 'status': 'ready', 'note': 'Pickup at counter 2', 'items': [{'item_id': 11, 'quantity': 2}, {'item_id': 16, 'quantity': 2}]}, {'user_id': 6, 'status': 'completed', 'note': 'Paid by cash', 'items': [{'item_id': 9, 'quantity': 1}, {'item_id': 32, 'quantity': 1}]}, {'user_id': 7, 'status': 'cancelled', 'note': 'Customer cancelled before preparation', 'items': [{'item_id': 35, 'quantity': 1}]}, {'user_id': 3, 'status': 'completed', 'note': 'Vegetarian lunch order', 'items': [{'item_id': 29, 'quantity': 1}, {'item_id': 31, 'quantity': 1}, {'item_id': 19, 'quantity': 1}]}, {'user_id': 4, 'status': 'completed', 'note': 'Group snack order', 'items': [{'item_id': 22, 'quantity': 2}, {'item_id': 25, 'quantity': 1}]}, {'user_id': 5, 'status': 'confirmed', 'note': 'Breakfast pickup', 'items': [{'item_id': 28, 'quantity': 1}, {'item_id': 17, 'quantity': 1}]}]


def get_or_create_user(db, *, name: str, email: str, password: str, role: UserRole) -> User:
    user = db.query(User).filter(User.email == email).first()
    if user:
        user.name = name
        user.role = role
        return user
    user = User(name=name, email=email, password_hash=hash_password(password), role=role)
    db.add(user)
    db.flush()
    return user


def main():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        admin = get_or_create_user(
            db,
            name="QuickBite Admin",
            email="admin@quickbite.com",
            password="Admin@123",
            role=UserRole.admin,
        )
        customer = get_or_create_user(
            db,
            name="Demo Customer",
            email="customer@quickbite.com",
            password="Customer@123",
            role=UserRole.customer,
        )
        user_map = {1: admin, 2: customer}

        for staff_data in STAFF_USERS:
            get_or_create_user(
                db,
                name=staff_data["name"],
                email=staff_data["email"],
                password=staff_data["password"],
                role=UserRole(staff_data["role"]),
            )

        for index, customer_data in enumerate(EXTRA_CUSTOMERS, start=3):
            user_map[index] = get_or_create_user(
                db,
                name=customer_data["name"],
                email=customer_data["email"],
                password=customer_data["password"],
                role=UserRole.customer,
            )

        ensure_default_settings(db)

        category_map = {}
        for category_name in CATEGORIES:
            category = db.query(Category).filter(Category.name == category_name).first()
            if not category:
                category = Category(name=category_name)
                db.add(category)
                db.flush()
            category_map[category_name] = category

        item_map = {}
        item_id_map = {}
        for index, item_data in enumerate(ITEMS, start=1):
            item = db.query(Item).filter(Item.name == item_data["name"]).first()
            if not item:
                item = Item(name=item_data["name"])
                db.add(item)
            item.description = item_data["description"]
            item.price = item_data["price"]
            item.category_id = category_map[item_data["category"]].id
            item.image_url = item_data["image_url"]
            item.is_available = item_data.get("is_available", True)
            db.flush()
            item_map[item.name] = item
            item_id_map[index] = item

        # Create sample orders only if no orders exist yet.
        if db.query(Order).count() == 0:
            for order_data in SAMPLE_ORDERS:
                total = 0.0
                line_items = []
                for line in order_data["items"]:
                    item = item_id_map[line["item_id"]]
                    total += item.price * line["quantity"]
                    line_items.append(OrderItem(item_id=item.id, quantity=line["quantity"], price=item.price))

                order = Order(
                    user_id=user_map[order_data["user_id"]].id,
                    status=OrderStatus(order_data["status"]),
                    total=round(total, 2),
                    note=order_data["note"],
                    items=line_items,
                )
                db.add(order)
                db.flush()
                order.order_code = f"QB-{order.id:04d}"
                method = PaymentMethod.cod
                db.add(Payment(order_id=order.id, method=method, status=PaymentStatus.cod, amount=order.total))

        db.commit()
        print("Seed data completed: 9 users, 8 categories, 35 menu items, 10 sample orders, settings and payments.")
        print("Admin:    admin@quickbite.com / Admin@123")
        print("Customer: customer@quickbite.com / Customer@123")
        print("Kitchen:  kitchen@quickbite.com / Customer@123")
        print("Delivery: delivery@quickbite.com / Customer@123")
    finally:
        db.close()


if __name__ == "__main__":
    main()
