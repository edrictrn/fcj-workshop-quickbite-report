"""Initialize the local SQLite database from raw SQL files.

Run:
    python scripts/init_db_sqlite.py

This creates/recreates quickbite.db using:
    sql/schema_sqlite.sql
    sql/seed_sqlite.sql
"""

from pathlib import Path
import sqlite3

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = PROJECT_ROOT / "quickbite.db"
SCHEMA_PATH = PROJECT_ROOT / "sql" / "schema_sqlite.sql"
SEED_PATH = PROJECT_ROOT / "sql" / "seed_sqlite.sql"
VIEWS_PATH = PROJECT_ROOT / "sql" / "views_sqlite.sql"


def execute_sql_file(connection: sqlite3.Connection, path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"SQL file not found: {path}")
    sql = path.read_text(encoding="utf-8")
    connection.executescript(sql)


def main() -> None:
    if DB_PATH.exists():
        DB_PATH.unlink()

    with sqlite3.connect(DB_PATH) as connection:
        connection.execute("PRAGMA foreign_keys = ON;")
        execute_sql_file(connection, SCHEMA_PATH)
        execute_sql_file(connection, SEED_PATH)
        execute_sql_file(connection, VIEWS_PATH)
        connection.commit()

    print(f"SQLite database created: {DB_PATH}")
    print("Seed data: 9 users, 8 categories, 35 menu items, 10 sample orders, 10 payments, 3 operation logs")
    print("Views: v_daily_revenue, v_item_sales, v_order_status_counts")
    print("Admin:    admin@quickbite.com / Admin@123")
    print("Customer: customer@quickbite.com / Customer@123")
    print("Kitchen:  kitchen@quickbite.com / Customer@123")
    print("Delivery: delivery@quickbite.com / Customer@123")


if __name__ == "__main__":
    main()
