def test_list_menu(client):
    res = client.get("/menu/")
    assert res.status_code == 200
    assert len(res.json()) > 0


def test_menu_filter_and_sort(client):
    res = client.get("/menu/", params={"max_price": 40000, "sort_by": "price", "sort_order": "desc"})
    assert res.status_code == 200
    prices = [i["price"] for i in res.json()]
    assert all(p <= 40000 for p in prices)
    assert prices == sorted(prices, reverse=True)


def test_create_item_requires_admin(client, customer_headers):
    res = client.post("/menu/", json={"name": "Hacky", "price": 1000, "category_id": 1}, headers=customer_headers)
    assert res.status_code == 403
