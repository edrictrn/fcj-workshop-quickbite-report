"""Full order lifecycle: customer -> admin confirm -> kitchen -> delivery -> completed,
and the dashboard reflects the finished order."""


def _headers(client, email, password="Customer@123"):
    r = client.post("/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def test_full_order_lifecycle(client):
    customer = _headers(client, "customer@quickbite.com")
    admin = _headers(client, "admin@quickbite.com", "Admin@123")
    kitchen = _headers(client, "kitchen@quickbite.com")
    delivery = _headers(client, "delivery@quickbite.com")

    dash_before = client.get("/orders/admin/dashboard", headers=admin).json()

    # 1. Customer places an order
    order = client.post(
        "/orders/",
        json={"items": [{"item_id": 1, "quantity": 2}], "note": "flow", "payment_method": "cod"},
        headers=customer,
    ).json()
    oid = order["id"]
    assert order["status"] == "pending"

    # 2..5 transitions through the operational pipeline
    def patch(headers, status):
        r = client.patch(f"/orders/{oid}/status", json={"status": status}, headers=headers)
        assert r.status_code == 200, r.text
        return r.json()

    patch(admin, "confirmed")       # restaurant confirms
    patch(kitchen, "preparing")     # kitchen starts
    patch(kitchen, "ready")         # kitchen done
    final = patch(delivery, "completed")  # delivery finishes

    assert final["status"] == "completed"

    # Status history captured every step (creation + 4 transitions)
    statuses = [h["new_status"] for h in final["status_history"]]
    assert statuses == ["pending", "confirmed", "preparing", "ready", "completed"]

    # 6. Dashboard reflects the finished order
    dash_after = client.get("/orders/admin/dashboard", headers=admin).json()
    assert dash_after["total_orders"] == dash_before["total_orders"] + 1
    assert dash_after["status_counts"].get("completed", 0) >= 1


def test_role_cannot_skip_pipeline(client):
    """A delivery staffer cannot move a fresh order straight to preparing."""
    customer = _headers(client, "customer@quickbite.com")
    delivery = _headers(client, "delivery@quickbite.com")
    order = client.post(
        "/orders/",
        json={"items": [{"item_id": 2, "quantity": 1}], "note": None, "payment_method": "cod"},
        headers=customer,
    ).json()
    r = client.patch(f"/orders/{order['id']}/status", json={"status": "preparing"}, headers=delivery)
    assert r.status_code == 403
