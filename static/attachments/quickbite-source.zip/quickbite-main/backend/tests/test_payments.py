def test_mock_payment_complete(client, customer_headers):
    order = client.post(
        "/orders/",
        json={"items": [{"item_id": 1, "quantity": 1}], "note": None, "payment_method": "mock_ewallet"},
        headers=customer_headers,
    ).json()
    assert order["payment"]["status"] == "pending"
    pid = order["payment"]["id"]

    res = client.post(f"/payments/{pid}/mock-complete", json={"success": True}, headers=customer_headers)
    assert res.status_code == 200
    assert res.json()["status"] == "paid"

    # order should move from pending -> confirmed after payment
    detail = client.get(f"/orders/{order['id']}", headers=customer_headers).json()
    assert detail["status"] == "confirmed"
