def _create_order(client, headers, item_id=1, qty=2, method="mock_ewallet"):
    return client.post(
        "/orders/",
        json={"items": [{"item_id": item_id, "quantity": qty}], "note": "t", "payment_method": method},
        headers=headers,
    )


def test_create_order_persists_breakdown(client, customer_headers):
    res = _create_order(client, customer_headers)
    assert res.status_code == 201
    d = res.json()
    assert d["subtotal"] + d["delivery_fee"] + d["tax_amount"] == d["total"]
    assert d["lookup_token"]
    assert any(h["new_status"] == "pending" for h in d["status_history"])


def test_create_order_nonexistent_item(client, customer_headers):
    res = _create_order(client, customer_headers, item_id=999999)
    assert res.status_code == 404


def test_lookup_requires_token(client, customer_headers):
    d = _create_order(client, customer_headers).json()
    code = d["order_code"]
    assert client.get(f"/orders/lookup/{code}").status_code == 422
    assert client.get(f"/orders/lookup/{code}", params={"token": "wrong"}).status_code == 404
    ok = client.get(f"/orders/lookup/{code}", params={"token": d["lookup_token"]})
    assert ok.status_code == 200 and ok.json()["order_code"] == code


def test_admin_update_status_records_history(client, customer_headers, admin_headers):
    d = _create_order(client, customer_headers).json()
    res = client.patch(f"/orders/{d['id']}/status", json={"status": "confirmed", "note": "ok"}, headers=admin_headers)
    assert res.status_code == 200
    hist = res.json()["status_history"]
    assert hist[-1]["new_status"] == "confirmed"
