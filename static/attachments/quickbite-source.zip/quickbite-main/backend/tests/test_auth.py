def test_login_success(client):
    res = client.post("/auth/login", json={"email": "admin@quickbite.com", "password": "Admin@123"})
    assert res.status_code == 200
    assert res.json()["access_token"]


def test_login_wrong_password(client):
    res = client.post("/auth/login", json={"email": "admin@quickbite.com", "password": "nope"})
    assert res.status_code == 401


def test_me_requires_auth(client):
    assert client.get("/auth/me").status_code == 401


def test_customer_cannot_access_admin(client, customer_headers):
    res = client.get("/orders/admin/dashboard", headers=customer_headers)
    assert res.status_code == 403


def test_register_and_duplicate(client):
    payload = {"name": "New User", "email": "newuser_test@quickbite.com", "password": "Passw0rd!"}
    first = client.post("/auth/register", json=payload)
    assert first.status_code == 201
    dup = client.post("/auth/register", json=payload)
    assert dup.status_code == 400
