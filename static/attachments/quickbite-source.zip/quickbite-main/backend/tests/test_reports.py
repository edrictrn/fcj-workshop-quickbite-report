def test_daily_revenue_excludes_cancelled(client, admin_headers):
    rows = client.get("/reports/daily-revenue", params={"days": 60}, headers=admin_headers).json()
    report_total = sum(r["revenue"] for r in rows)

    dash = client.get("/orders/admin/dashboard", headers=admin_headers).json()
    # dashboard total_revenue also excludes cancelled, so the two must agree
    assert round(report_total, 2) == round(dash["total_revenue"], 2)


def test_top_items_and_status_counts(client, admin_headers):
    top = client.get("/reports/top-items", params={"limit": 3}, headers=admin_headers)
    assert top.status_code == 200 and len(top.json()) <= 3
    sc = client.get("/reports/status-counts", headers=admin_headers)
    assert sc.status_code == 200 and "cancelled" in sc.json()
