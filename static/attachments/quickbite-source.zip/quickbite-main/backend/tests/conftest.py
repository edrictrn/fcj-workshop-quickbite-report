"""Pytest fixtures: build a fresh SQLite DB from the SQL files and expose a TestClient."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import pytest
from fastapi.testclient import TestClient

from scripts.init_db_sqlite import main as init_db_from_sql
from main import app
from rate_limit import limiter


@pytest.fixture(scope="session", autouse=True)
def _database():
    init_db_from_sql()
    # Disable rate limiting for the general test suite so repeated logins don't 429.
    limiter.enabled = False
    yield


@pytest.fixture()
def client():
    return TestClient(app)


def _headers(client, email, password):
    res = client.post("/auth/login", json={"email": email, "password": password})
    assert res.status_code == 200, res.text
    return {"Authorization": f"Bearer {res.json()['access_token']}"}


@pytest.fixture()
def admin_headers(client):
    return _headers(client, "admin@quickbite.com", "Admin@123")


@pytest.fixture()
def customer_headers(client):
    return _headers(client, "customer@quickbite.com", "Customer@123")
