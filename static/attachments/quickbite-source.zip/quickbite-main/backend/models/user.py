import enum
from sqlalchemy import Column, Enum, Integer, String
from sqlalchemy.orm import relationship

from database import Base


class UserRole(str, enum.Enum):
    customer = "customer"
    admin = "admin"
    kitchen_staff = "kitchen_staff"
    delivery_staff = "delivery_staff"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(Enum(UserRole), default=UserRole.customer, nullable=False)

    orders = relationship("Order", back_populates="user")
    operation_logs = relationship("OperationLog", back_populates="user")
