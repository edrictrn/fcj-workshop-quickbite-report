from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field

from .payment import PaymentResponse
from .user import UserResponse


class OrderItemRequest(BaseModel):
    item_id: int = Field(..., gt=0)
    quantity: int = Field(..., ge=1, le=99)


class CreateOrderRequest(BaseModel):
    items: List[OrderItemRequest] = Field(..., min_length=1)
    note: Optional[str] = Field(default=None, max_length=255)
    payment_method: str = Field(default="cod", pattern="^(cod|mock_ewallet)$")


class OrderItemResponse(BaseModel):
    item_id: int
    item_name: Optional[str] = None
    quantity: int
    price: float

    class Config:
        from_attributes = True


class OrderStatusHistoryResponse(BaseModel):
    old_status: Optional[str] = None
    new_status: str
    changed_by: Optional[int] = None
    note: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class OrderResponse(BaseModel):
    id: int
    order_code: Optional[str] = None
    lookup_token: Optional[str] = None
    status: str
    subtotal: float = 0
    delivery_fee: float = 0
    tax_amount: float = 0
    total: float
    note: Optional[str]
    created_at: datetime
    items: List[OrderItemResponse]
    payment: Optional[PaymentResponse] = None
    status_history: List[OrderStatusHistoryResponse] = []

    class Config:
        from_attributes = True


class AdminOrderResponse(OrderResponse):
    user: UserResponse


class UpdateOrderStatusRequest(BaseModel):
    status: str
    note: Optional[str] = Field(default=None, max_length=255)
