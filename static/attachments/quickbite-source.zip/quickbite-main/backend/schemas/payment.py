from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class PaymentRequest(BaseModel):
    order_id: int = Field(..., gt=0)
    method: str = Field(default="cod", pattern="^(cod|mock_ewallet)$")


class PaymentCompleteRequest(BaseModel):
    success: bool = True


class PaymentResponse(BaseModel):
    id: int
    order_id: int
    method: str
    status: str
    amount: float
    provider_transaction_id: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    paid_at: Optional[datetime] = None

    class Config:
        from_attributes = True
