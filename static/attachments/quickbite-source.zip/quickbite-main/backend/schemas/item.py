from typing import Optional
from pydantic import BaseModel, Field


class CategoryResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class CreateCategoryRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=80)


class ItemRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=120)
    description: Optional[str] = None
    price: float = Field(..., gt=0)
    category_id: int = Field(..., gt=0)
    is_available: bool = True
    image_url: Optional[str] = None


class ItemUpdateRequest(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    description: Optional[str] = None
    price: Optional[float] = Field(default=None, gt=0)
    category_id: Optional[int] = Field(default=None, gt=0)
    is_available: Optional[bool] = None
    image_url: Optional[str] = None


class ItemResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    price: float
    image_url: Optional[str]
    is_available: bool
    category: Optional[CategoryResponse]

    class Config:
        from_attributes = True
