"""Local email utilities for QuickBite.

The project can send email in two modes:
- Local/Docker demo: FastAPI -> SMTP -> Mailpit web inbox at http://localhost:8025
- AWS phase: replace this local SMTP path with Lambda + SES, or point SMTP to SES.

Email delivery is intentionally fail-silent by default so an email problem does not
break the core order creation flow during demos.
"""

from __future__ import annotations

import os
import smtplib
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from typing import Any


def _env_bool(key: str, default: bool = False) -> bool:
    raw = os.getenv(key)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


@dataclass(frozen=True)
class EmailSettings:
    enabled: bool
    backend: str
    from_email: str
    from_name: str
    smtp_host: str
    smtp_port: int
    smtp_username: str | None
    smtp_password: str | None
    smtp_use_tls: bool
    smtp_use_ssl: bool
    fail_silently: bool


def get_email_settings() -> EmailSettings:
    return EmailSettings(
        enabled=_env_bool("EMAIL_ENABLED", False),
        backend=os.getenv("EMAIL_BACKEND", "smtp").strip().lower(),
        from_email=os.getenv("EMAIL_FROM", "no-reply@quickbite.local"),
        from_name=os.getenv("EMAIL_FROM_NAME", "QuickBite"),
        smtp_host=os.getenv("SMTP_HOST", "localhost"),
        smtp_port=int(os.getenv("SMTP_PORT", "1025")),
        smtp_username=os.getenv("SMTP_USERNAME") or None,
        smtp_password=os.getenv("SMTP_PASSWORD") or None,
        smtp_use_tls=_env_bool("SMTP_USE_TLS", False),
        smtp_use_ssl=_env_bool("SMTP_USE_SSL", False),
        fail_silently=_env_bool("EMAIL_FAIL_SILENTLY", True),
    )


def get_safe_email_config() -> dict[str, Any]:
    settings = get_email_settings()
    return {
        "enabled": settings.enabled,
        "backend": settings.backend,
        "from_email": settings.from_email,
        "from_name": settings.from_name,
        "smtp_host": settings.smtp_host,
        "smtp_port": settings.smtp_port,
        "smtp_username_configured": bool(settings.smtp_username),
        "smtp_password_configured": bool(settings.smtp_password),
        "smtp_use_tls": settings.smtp_use_tls,
        "smtp_use_ssl": settings.smtp_use_ssl,
        "fail_silently": settings.fail_silently,
        "local_mailpit_inbox": "http://localhost:8025",
    }


def send_email(to_email: str, subject: str, text_body: str, html_body: str | None = None) -> dict[str, Any]:
    """Send an email using the configured backend.

    Returns a small status dict instead of raising when EMAIL_FAIL_SILENTLY=true.
    This keeps order creation stable even if the local SMTP demo service is down.
    """

    settings = get_email_settings()
    if not settings.enabled:
        return {"status": "disabled", "detail": "EMAIL_ENABLED=false"}

    if settings.backend != "smtp":
        return {
            "status": "skipped",
            "detail": f"EMAIL_BACKEND={settings.backend!r} is reserved for AWS Lambda/SES phase",
        }

    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = f"{settings.from_name} <{settings.from_email}>"
        msg["To"] = to_email
        msg.set_content(text_body)
        if html_body:
            msg.add_alternative(html_body, subtype="html")

        if settings.smtp_use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, context=context, timeout=10) as server:
                if settings.smtp_username and settings.smtp_password:
                    server.login(settings.smtp_username, settings.smtp_password)
                server.send_message(msg)
        else:
            with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=10) as server:
                if settings.smtp_use_tls:
                    server.starttls(context=ssl.create_default_context())
                if settings.smtp_username and settings.smtp_password:
                    server.login(settings.smtp_username, settings.smtp_password)
                server.send_message(msg)

        return {"status": "sent", "to": to_email, "subject": subject}
    except Exception as exc:  # noqa: BLE001 - demo utility returns readable error
        if settings.fail_silently:
            print(f"[email] Failed to send email to {to_email}: {exc}")
            return {"status": "failed", "detail": str(exc)}
        raise


def _money(value: float | int | None) -> str:
    amount = float(value or 0)
    return f"{amount:,.0f} VND"


def _order_items_text(order) -> str:
    lines = []
    for order_item in order.items:
        name = getattr(order_item, "item_name", None) or f"Item #{order_item.item_id}"
        lines.append(f"- {name} x{order_item.quantity}: {_money(order_item.quantity * order_item.price)}")
    return "\n".join(lines) if lines else "- No items"


def _order_items_html(order) -> str:
    rows = []
    for order_item in order.items:
        name = getattr(order_item, "item_name", None) or f"Item #{order_item.item_id}"
        rows.append(
            "<tr>"
            f"<td>{name}</td>"
            f"<td style='text-align:center'>{order_item.quantity}</td>"
            f"<td style='text-align:right'>{_money(order_item.price)}</td>"
            f"<td style='text-align:right'>{_money(order_item.quantity * order_item.price)}</td>"
            "</tr>"
        )
    return "".join(rows)


def send_order_confirmation_email(order) -> dict[str, Any]:
    user = order.user
    if not user or not user.email:
        return {"status": "skipped", "detail": "Order has no recipient email"}

    order_code = order.order_code or f"#{order.id}"
    payment = getattr(order, "payment", None)
    payment_method = getattr(getattr(payment, "method", None), "value", getattr(payment, "method", "N/A"))
    payment_status = getattr(getattr(payment, "status", None), "value", getattr(payment, "status", "N/A"))
    status = getattr(order.status, "value", str(order.status))

    subject = f"[QuickBite] Xác nhận đơn hàng {order_code}"
    text_body = f"""Xin chào {user.name},

QuickBite đã ghi nhận đơn hàng {order_code} của bạn.

Trạng thái đơn: {status}
Phương thức thanh toán: {payment_method}
Trạng thái thanh toán: {payment_status}
Tổng tiền: {_money(order.total)}

Chi tiết món:
{_order_items_text(order)}

Bạn có thể tra cứu đơn bằng mã: {order_code}

Email này đang được gửi qua SMTP local/Mailpit trong giai đoạn demo trước khi tích hợp AWS Lambda + SES.

QuickBite Team
"""
    html_body = f"""
    <div style="font-family:Arial,sans-serif;line-height:1.5;color:#222">
      <h2>QuickBite đã ghi nhận đơn hàng của bạn 🍔</h2>
      <p>Xin chào <strong>{user.name}</strong>,</p>
      <p>Đơn hàng <strong>{order_code}</strong> đã được tạo thành công.</p>
      <ul>
        <li>Trạng thái đơn: <strong>{status}</strong></li>
        <li>Phương thức thanh toán: <strong>{payment_method}</strong></li>
        <li>Trạng thái thanh toán: <strong>{payment_status}</strong></li>
        <li>Tổng tiền: <strong>{_money(order.total)}</strong></li>
      </ul>
      <table style="border-collapse:collapse;width:100%;max-width:680px">
        <thead>
          <tr>
            <th style="text-align:left;border-bottom:1px solid #ddd;padding:8px">Món</th>
            <th style="text-align:center;border-bottom:1px solid #ddd;padding:8px">SL</th>
            <th style="text-align:right;border-bottom:1px solid #ddd;padding:8px">Đơn giá</th>
            <th style="text-align:right;border-bottom:1px solid #ddd;padding:8px">Thành tiền</th>
          </tr>
        </thead>
        <tbody>{_order_items_html(order)}</tbody>
      </table>
      <p>Bạn có thể tra cứu đơn bằng mã: <strong>{order_code}</strong>.</p>
      <p style="color:#666;font-size:13px">Email này đang được gửi qua SMTP local/Mailpit trong giai đoạn demo trước khi tích hợp AWS Lambda + SES.</p>
    </div>
    """
    return send_email(user.email, subject, text_body, html_body)


def send_order_status_email(order, old_status: str | None = None) -> dict[str, Any]:
    user = order.user
    if not user or not user.email:
        return {"status": "skipped", "detail": "Order has no recipient email"}

    order_code = order.order_code or f"#{order.id}"
    new_status = getattr(order.status, "value", str(order.status))
    subject = f"[QuickBite] Cập nhật trạng thái đơn {order_code}: {new_status}"
    transition = f"{old_status} -> {new_status}" if old_status else new_status
    text_body = f"""Xin chào {user.name},

Đơn hàng {order_code} của bạn vừa được cập nhật trạng thái.

Trạng thái: {transition}
Tổng tiền: {_money(order.total)}

Bạn có thể tra cứu đơn bằng mã: {order_code}

QuickBite Team
"""
    html_body = f"""
    <div style="font-family:Arial,sans-serif;line-height:1.5;color:#222">
      <h2>Cập nhật trạng thái đơn hàng QuickBite</h2>
      <p>Xin chào <strong>{user.name}</strong>,</p>
      <p>Đơn hàng <strong>{order_code}</strong> vừa được cập nhật.</p>
      <p>Trạng thái: <strong>{transition}</strong></p>
      <p>Tổng tiền: <strong>{_money(order.total)}</strong></p>
      <p>Bạn có thể tra cứu đơn bằng mã: <strong>{order_code}</strong>.</p>
    </div>
    """
    return send_email(user.email, subject, text_body, html_body)
