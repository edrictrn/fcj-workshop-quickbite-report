from typing import Optional

from models import OperationLog


def _role_value(actor) -> Optional[str]:
    if actor is None:
        return None
    return actor.role.value if hasattr(actor.role, "value") else str(actor.role)


def log_operation(db, actor, *, action: str, target_type: str, target_id: Optional[object] = None, detail: Optional[str] = None) -> None:
    """Add an audit log row. Caller commits together with the business transaction."""
    db.add(
        OperationLog(
            user_id=getattr(actor, "id", None),
            actor_email=getattr(actor, "email", None),
            actor_role=_role_value(actor),
            action=action,
            target_type=target_type,
            target_id=None if target_id is None else str(target_id),
            detail=detail,
        )
    )
