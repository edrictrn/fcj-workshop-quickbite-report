from decimal import Decimal, InvalidOperation

from models import SystemConfig

DEFAULT_SETTINGS = {
    "delivery_fee": ("15000", "Default delivery/service fee in VND."),
    "tax_rate": ("0.00", "VAT/service tax rate. Example: 0.08 means 8%."),
    "min_order_value": ("0", "Minimum subtotal required before checkout."),
    "restaurant_open": ("true", "Whether QuickBite accepts new orders."),
    "enforce_open_hours": ("false", "If true, block orders outside the open/close time window."),
    "restaurant_open_time": ("07:00", "Daily opening time, Asia/Ho_Chi_Minh."),
    "restaurant_close_time": ("21:30", "Daily closing time, Asia/Ho_Chi_Minh."),
    "service_area": ("Campus A, Campus B, nearby offices", "Delivery/pickup service area."),
}


def ensure_default_settings(db) -> None:
    for key, (value, description) in DEFAULT_SETTINGS.items():
        exists = db.query(SystemConfig).filter(SystemConfig.key == key).first()
        if not exists:
            db.add(SystemConfig(key=key, value=value, description=description))


def get_setting(db, key: str, default: str = "") -> str:
    row = db.query(SystemConfig).filter(SystemConfig.key == key).first()
    return row.value if row else default


def get_setting_float(db, key: str, default: float = 0.0) -> float:
    try:
        return float(get_setting(db, key, str(default)))
    except (TypeError, ValueError):
        return default


def get_setting_bool(db, key: str, default: bool = True) -> bool:
    value = get_setting(db, key, str(default)).strip().lower()
    return value in {"1", "true", "yes", "on", "open"}


def get_setting_decimal(db, key: str, default: str = "0") -> Decimal:
    try:
        return Decimal(get_setting(db, key, str(default)))
    except (TypeError, InvalidOperation):
        return Decimal(str(default))
